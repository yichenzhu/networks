#ifndef CHANNEL_H
#define CHANNEL_H

/*
 * channel.c: Channel functions
 *
 * Use these functions to implement channels. Each function creates, modifies,
 * deletes, or keeps track of channels and information regarding channels.
 *
 * num_channels: number of channels
 * add_channel: add a channel
 * update_channel_topic: updates channel's topic
 * del_channel: deletes given channel
 * del_channel_by_name: deletes given channel by name
 * find_channel: finds given channel
 * add_user_to_channel: add given user to channel
 * is_user_in_channel: returns boolean to see if given user is in channel
 * user_count_in_channel: number of users in channel
 * del_user_from_channel: deletes given user from channel
 * add_operator: adds user as operator to channel
 * is_user_channel_operator: returns boolean to see if given user is channel operator
 * find_channel_operator: returns user who is channel operator
 * delete_operator: deletes user as channel operator
 */

#include <stdbool.h>
#include "uthash.h"

#define MAX_LEN_CHANNEL_NAME    64

struct server_ctx;
struct user;

typedef struct {
    char    name[MAX_LEN_CHANNEL_NAME];
    int     mode;
    char*   topic;
    struct  user_in_channel* channel_users;
    struct  user_in_channel* operators;
    UT_hash_handle hh; /* makes this structure hashable */
} channel_info;

/*
 * num_channels - given information about the server, returns number of channels
 *
 * ctx - struct with information regarding the server incl. channels lock,
 * channels information, etc. see server.h for full struct
 *
 * Returns - number of channels
 */
unsigned int num_channels(struct server_ctx* ctx);

/*
 * add_channel - given information about the server and a specified channel name,
 * the function creates a channel
 *
 * ctx - struct with information regarding the server incl. channels information,
 * channel, etc. see server.h for full struct
 *
 * Returns - nothing.
 */
void add_channel(struct server_ctx* ctx, char* cname);

/*
 * update_channel_topic - given information about the server, specified channel
 * information, and specified topic, the function changes the topic of the channel
 *
 * ctx - struct with information regarding the server incl. channel lock, etc.
 * see server.h for full struct
 *
 * ci - struct with information regarding the channel. see "channel_info" struct above.
 *
 * topic - specified channel topic
 *
 * Returns - nothing.
 */
void update_channel_topic(struct server_ctx* ctx, channel_info* ci, char* topic);

/*
 * find_channel - given information about the server and a specified channel name,
 * the function finds the specified channel
 *
 * ctx - struct with information regarding server incl. channel lock,
 * channels, channel name, etc. see server.h for full struct
 *
 * cname - specified channel name
 *
 * Returns - the channel information struct.
 */
channel_info* find_channel(struct server_ctx* ctx, char* cname);

/*
 * del_channel - given information about the server and a specified channel's
 * information, the function deletes the channel
 *
 * ctx - struct with information regarding server incl. channels lock, channels, etc.
 * see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * Returns - nothing.
 */
void del_channel(struct server_ctx* ctx, channel_info* ci);

/*
 * del_channel_by_name - given information about the server and a specified channel's
 * name, the function deletes the channel
 *
 * ctx - struct with information regarding server incl. channels lock, channels, etc.
 * see server.h for full struct
 *
 * cname - specified channel name
 *
 * Returns - nothing.
 */
void del_channel_by_name(struct server_ctx* ctx, char* cname);

/*
 * find_user_in_channel - given information about the server and a specified channel's
 * information, and a user's nickname, the function returns user in channel
 *
 * ctx - struct with information regarding server incl. channels lock, etc. see
 * server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * Returns - user struct
 */
struct user_in_channel* find_user_in_channel(struct server_ctx* ctx, channel_info* ci, char* nick);

/*
 * add_user_to_channel - given information about the server and a specified channel's
 * information, and user, the function adds user to channel
 *
 * ctx - struct with information regarding server incl. channels lock. see server.h
 * for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * u - user struct (the one being added to server)
 *
 * Returns - nothing.
 */
void add_user_to_channel(struct server_ctx* ctx, channel_info* ci, struct user* u);

/*
 * is_user_in_channel - given information about the server and a specified channel's
 * information, and specified nickname of user, the function returns a boolean
 * whether the user is in the channel
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nick - the specified user's nickname
 *
 * Returns - a boolean on whether the user is in the channel
 */
bool is_user_in_channel(struct server_ctx* ctx, channel_info* ci, char* nick);

/*
 * user_count_in_channel - given information about a server and a specified channel's
 * information, function returns the number of users in given channel
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * Returns - number of users in channel.
 */
int user_count_in_channel(struct server_ctx* ctx, channel_info* ci);

/*
 * del_user_from_channel - given information about a server and a specified channel's
 * information, and a specified user's nickname, the function deletes user from channel
 *
 * ctx - struct with information regarding server. see server.h, for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nickname - specified user's nickname
 *
 * Returns - nothing.
 */
void del_user_from_channel(struct server_ctx* ctx, channel_info* ci, char* nickname);

/*
 * add_operator - given information about a server and a specified channel's
 * information, and a given user's nickname, the function adds given user as channel
 * operator
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nickname - specified user's nickname
 *
 * Returns - nothing.
 */
void add_operator(struct server_ctx* ctx, channel_info* ci, char *nickname);

/*
 * is_user_channel_operator - given information about a server and a specified channel's
 * information, and a given user's nickname, the function returns a boolean to see
 * if given user is channel operator
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nick - the specified user's nickname
 *
 * Returns - boolean to see if given user is channel operator.
 */
bool is_user_channel_operator(struct server_ctx* ctx, channel_info* ci, char* nick);

/*
 * find_channel_operator - given information about a server and specified channel's
 * information, and a given user's nickname, the function finds the channel operator
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nick - the specified user's nickname
 *
 * Returns - user that is the channel operator.
 */
struct user_in_channel* find_channel_operator(struct server_ctx* ctx, channel_info* ci, char* nick);

/*
 * delete_operator - given information about a server and specified channel's information
 * and a given user's nickname, the function deletes the channel operator
 *
 * ctx - struct with information regarding server. see server.h for full struct
 *
 * ci - the specified channel's information struct. see above for full struct
 *
 * nick - the specified user's nickname
 *
 * Returns - nothing.
 */
void delete_operator(struct server_ctx* ctx, channel_info* ci, char *nickname);


#endif
