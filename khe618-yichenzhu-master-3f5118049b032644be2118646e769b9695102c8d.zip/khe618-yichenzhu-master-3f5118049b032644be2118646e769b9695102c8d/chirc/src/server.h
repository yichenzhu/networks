#ifndef SERVER_H
#define SERVER_H

/*
 * server.c - Server functions
 *
 * add_user - adds user to server
 * update_user - updates user in server
 * del_user - deletes user in server
 * find_user - finds user in server
 * set_user_mode - sets user mode in server
 * find_user_by_username - finds user by username
 *
 */

#include <pthread.h>
#include <stdbool.h>

#include "uthash.h"
#include "channel.h"

#define MAX_LEN_SVR_CFG 1024
#define MAX_LEN_USER_NAME 64
#define MAX_LEN_HOST_NAME 128

#if !defined(strlcpy)
#define USE_MY_SAFE_STR_FUNCS
size_t strlcpy(char * dst, const char * src, size_t maxlen);
size_t strlcat(char * restrict dst, const char * restrict src, size_t maxlen);
#endif

//    a - user is flagged as away;
//    i - marks a users as invisible;
//    w - user receives wallops;
//    r - restricted user connection;
//    o - operator flag;
//    O - local operator flag;
//    s - marks a user for receipt of server notices.
#define USER_MODE_AWAY "a"
#define USER_MODE_INVISIBLE "i"
#define USER_MODE_WALLOPS "w"
#define USER_MODE_RESTRICTED "r"
#define USER_MODE_OPERATOR "o"
#define USER_MODE_LOCAL_OPR "O"
#define USER_MODE_RECEIPT "s"

struct user {
    char nickname[MAX_LEN_USER_NAME];
    char username[MAX_LEN_USER_NAME];
    char hostname[MAX_LEN_HOST_NAME];
    char realname[MAX_LEN_USER_NAME];
    int client_socket;
    char user_mode[16];
    char* away_message;
    int* is_irc_operator;
    bool is_local_user;
    UT_hash_handle hh; /* makes this structure hashable */
};

struct user_in_channel {
    char nickname[MAX_LEN_USER_NAME];
    int client_socket;
    UT_hash_handle hh; /* makes this structure hashable */
};

struct irc_server {
    char server_name[MAX_LEN_HOST_NAME];
    char ip_address[MAX_LEN_HOST_NAME];
    char port[16];
    char sverpasswd[MAX_LEN_USER_NAME];
    int server_socket;
    UT_hash_handle hh; // makes this structure hashable
};

struct server_ctx {
    unsigned int num_connections;
    struct user* users;
    channel_info* channels;
    struct irc_server* other_servers;


    char* server_name;
    char* ip_address;
    char* port;
    char* sverpasswd;
    char* operpasswd;
    char* nickname;
    pthread_mutex_t users_lock;
    pthread_mutex_t channels_lock;
    pthread_mutex_t servers_lock;
    pthread_mutex_t num_users_lock;
    pthread_mutex_t num_unknown_lock;
    pthread_mutex_t num_clients_lock;
    pthread_mutex_t num_opers_lock;
    pthread_mutex_t num_servers_lock;
    pthread_mutex_t send_lock;
    int* num_users;
    int* num_unknown;
    int* num_clients;
    int* num_opers;
    int* num_servers;
};

/*
 * ctx - server struct
 *
 * filename - file that contains irc specification
 *
 * server_to_run - name of the server to run
 *
 * Returns: number of servers in the network
 */
int read_server_configuration(struct server_ctx* ctx, char* file_name, char* server_to_run);

/*
 * ctx - server struct
 *
 * server_name - name of the server to get
 *
 * Returns: the server object specified by name
 */
struct irc_server*  get_irc_server(struct server_ctx* ctx, char* server_name);

/*
 * ctx - server struct
 *
 * socket - the socket associated with an irc server
 *
 * Returns: the server object specified by socket
 */
struct irc_server*  get_irc_server_by_socket(struct server_ctx* ctx, int socket);

/*
 * ctx - server struct
 *
 * server_name - name of the server to update
 *
 * socket - the socket associated with the server
 *
 * Returns: nothing
 */
void update_irc_server(struct server_ctx* ctx, char* server_name, int socket);

/*
 * add_user - adds user to server
 *
 * ctx - server struct
 *
 * nick - user's nickname
 *
 * client_socket - client socket ID
 *
 * Returns: nothing.
 */
void add_user(struct server_ctx* ctx, char* nick, int client_socket, bool local_user);

/*
 * update_user - updates user in server
 *
 * ctx - server struct
 *
 * nick - user's nickname
 *
 * username - username of given user
 *
 * realname - real name of user
 *
 * host - host id
 *
 * Returns: nothing.
 */
void update_user(struct server_ctx* ctx, char* nick, char* username, char *realname, char* host);

/*
 * update_user_nick - updates user in server
 *
 * ctx - server struct
 *
 * socket - the socket associated with the user
 *
 * old_nick - user's old nickname
 *
 * new_nick - user's new nickname
 *
 * Returns: the user updated
 */

struct user* update_user_nick(struct server_ctx* ctx, int socket, char* old_nick, char* new_nick);

/*
 * del_user - deletes user in server
 *
 * ctx - server struct
 *
 * nick - user's nickname
 *
 * Returns: nothing.
 */
void del_user(struct server_ctx* ctx, char* nick);

/*
 * find_user - finds user in server
 *
 * ctx - server struct
 *
 * nick - user's nickname
 *
 * Returns: user struct of given user.
 */
struct user* find_user(struct server_ctx* ctx, char* nick);

/*
 * set_user_mode - sets user mode
 *
 * ctx - server struct
 *
 * u - user struct
 *
 * set - boolean to determine if set or not
 *
 * mode - user mode
 *
 * info - information about user
 *
 * Returns: nothing.
 */
void set_user_mode(struct server_ctx* ctx, struct user* u, bool set, char* mode, char* info);

/*
 * find_user_by_username - finds user by username
 *
 * ctx - server struct
 *
 * username - username of user
 *
 * Returns: user struct of given username.
 */
struct user* find_user_by_username(struct server_ctx *ctx, char* username);


#endif
