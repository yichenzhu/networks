#include "channel.h"
#include "server.h"
#include "log.h"

unsigned int num_channels(struct server_ctx* ctx)
{
    pthread_mutex_lock(&ctx->channels_lock);
    unsigned int count = HASH_COUNT(ctx->channels);
    pthread_mutex_unlock(&ctx->channels_lock);
    return count;
}

void add_channel(struct server_ctx* ctx, char* cname)
{
    pthread_mutex_lock(&ctx->channels_lock);

    channel_info *new_channel = (channel_info *) malloc(sizeof(channel_info));
    strcpy(new_channel->name, cname);
    new_channel->mode = 0;      //TODO:
    new_channel->topic = NULL;
    new_channel->channel_users = NULL;
    new_channel->operators = NULL;
    HASH_ADD_STR(ctx->channels, name, new_channel);

    pthread_mutex_unlock(&ctx->channels_lock);
    chilog(INFO, "add new channel %s", cname);
}

void update_channel_topic(struct server_ctx* ctx, channel_info* ci, char* topic)
{
    pthread_mutex_lock(&ctx->channels_lock);
    if (ci->topic != NULL)
        free(ci->topic);
    ci->topic = strdup(topic);
    pthread_mutex_unlock(&ctx->channels_lock);
    chilog(INFO, "set channel topic %s", topic);
}

void del_channel(struct server_ctx* ctx, channel_info* ci)
{
    pthread_mutex_lock(&ctx->channels_lock);
    // Delete all users in this channel
    HASH_CLEAR(hh, ci->channel_users);

    HASH_DEL(ctx->channels, ci);
    pthread_mutex_unlock(&ctx->channels_lock);
    chilog(INFO, "delete channel %s", ci->name);

    if (ci->topic != NULL)
        free(ci->topic);

    free(ci);
}

void del_channel_by_name(struct server_ctx* ctx, char* cname)
{
    channel_info* ci = find_channel(ctx, cname);
    if (ci != NULL)
        del_channel(ctx, ci);
}

channel_info* find_channel(struct server_ctx* ctx, char* cname)
{
    channel_info* p_channel = NULL;
    pthread_mutex_lock(&ctx->channels_lock);

    HASH_FIND_STR(ctx->channels, cname, p_channel);
    pthread_mutex_unlock(&ctx->channels_lock);

    return p_channel;
}

void add_user_to_channel(struct server_ctx* ctx, channel_info* ci, struct user* u)
{
    pthread_mutex_lock(&ctx->channels_lock);
    struct user_in_channel* cu = (struct user_in_channel*)calloc(1, sizeof(struct user_in_channel));
    strcpy(cu->nickname, u->nickname);
    cu->client_socket = u->client_socket;
    HASH_ADD_STR(ci->channel_users, nickname, cu);
    pthread_mutex_unlock(&ctx->channels_lock);
    chilog(INFO, "add user %s to channel %s", u->nickname, ci->name);
}

void add_operator(struct server_ctx* ctx, channel_info* ci, char *nickname)
{
    pthread_mutex_lock(&ctx->channels_lock);
    struct user_in_channel* cu = (struct user_in_channel*)calloc(1, sizeof(struct user_in_channel));
    strcpy(cu->nickname, nickname);
    HASH_ADD_STR(ci->operators, nickname, cu);
    pthread_mutex_unlock(&ctx->channels_lock);
    chilog(INFO, "made user %s operator to channel %s", nickname, ci->name);
}

void delete_operator(struct server_ctx* ctx, channel_info* ci, char *nickname)
{
    struct user_in_channel* cu = find_channel_operator(ctx, ci, nickname);
    if (cu) {
        pthread_mutex_lock(&ctx->channels_lock);
        HASH_DEL(ci->operators, cu);
        pthread_mutex_unlock(&ctx->channels_lock);
    }

}


bool is_user_in_channel(struct server_ctx* ctx, channel_info* ci, char* nick)
{
    struct user_in_channel* cu = find_user_in_channel(ctx, ci, nick);
    return cu != NULL;
}

bool is_user_channel_operator(struct server_ctx* ctx, channel_info* ci, char* nick)
{
    struct user_in_channel* cu = find_channel_operator(ctx, ci, nick);
    return cu != NULL;
}

struct user_in_channel* find_channel_operator(struct server_ctx* ctx,
        channel_info* ci, char* nick)
{
    struct user_in_channel* cu = NULL;
    pthread_mutex_lock(&ctx->channels_lock);
    HASH_FIND_STR(ci->operators, nick, cu);
    pthread_mutex_unlock(&ctx->channels_lock);
    return cu;
}



int user_count_in_channel(struct server_ctx* ctx, channel_info* ci)
{
    pthread_mutex_lock(&ctx->channels_lock);
    int count = HASH_COUNT(ci->channel_users);
    pthread_mutex_unlock(&ctx->channels_lock);
    return count;
}

struct user_in_channel* find_user_in_channel(struct server_ctx* ctx,
        channel_info* ci, char* nick)
{
    struct user_in_channel* cu = NULL;
    pthread_mutex_lock(&ctx->channels_lock);
    HASH_FIND_STR(ci->channel_users, nick, cu);
    pthread_mutex_unlock(&ctx->channels_lock);

    return cu;
}


void del_user_from_channel(struct server_ctx* ctx, channel_info* ci, char* nickname)
{
    struct user_in_channel* cu = find_user_in_channel(ctx, ci, nickname);
    if (cu) {
        pthread_mutex_lock(&ctx->channels_lock);
        HASH_DEL(ci->channel_users, cu);
        pthread_mutex_unlock(&ctx->channels_lock);
    }


    unsigned int user_count = user_count_in_channel(ctx, ci);
    chilog(INFO, "delete user %s from channel %s, left count=%u", nickname, ci->name, user_count);
}
