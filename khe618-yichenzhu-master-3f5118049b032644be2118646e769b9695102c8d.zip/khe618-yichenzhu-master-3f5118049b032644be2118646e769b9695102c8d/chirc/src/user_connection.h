#ifndef USER_CONNECTION_H
#define USER_CONNECTION_H

/*
 * user_connection.c - Functions for user connections
 *
 * is_command - what is the command
 * split_string - splits the string
 * get_msg_from_socket - gets message from socket
 * preserve_left_over_msg - writes left over message into buffer
 * process_user_connections - processes user connections
 * service_single_client - services a single client
 *
 */

#include "uthash.h"
#include "message.h"
#include "server.h"

//comments in the .c file


/*
 * p_cmd- the command received
 *
 * Returns: 1 if command is recognized, 0 otherwise
 */
int is_command(char *p_cmd);

/*
 * str- the string to split
 *
 * delimiter- the delimiters to split by
 *
 * count- number of tokens found
 *
 * Returns: array of tokens
 */
char** split_string(char* str, char* delimiter, int* count);


/*
 * socket- the socket to receive bytes from
 *
 * bur- char buf to store the message
 *
 * buf_len- length of our buffer
 *
 * Returns- length of the message received
 */
int get_msg_from_socket(int socket, char* buf, int buf_len);

/*
 * preserve_left_over_msg - preserves the left over message that hasn't
 * been parsed to be parsed later
 *
 * left_over_msg: message that is not yet parsed
 *
 * buf: buffer to store left over message
 *
 * buf_len: length of buffer
 *
 * Returns: nothing.
 */
void preserve_left_over_msg(char* left_over_msg, char* buf, int buf_len);

/*
 * server_socket- the socket of the server
 *
 * ctx- the server context object
 *
 * Returns: success code of the connection
 */
int process_user_connections(int server_socket, struct server_ctx* ctx);

/*
 * args- the workers args passed to this thread
 *
 * Returns: nothing
 */
void *service_single_client(void *args);


/*
 * ctx- the server context object
 *
 * ip_address- the ip address to connect to
 *
 * port- the port to connect to
 *
 * Returns: the socket maintaining the connection
 */
int connect_to_server(struct server_ctx* ctx, char* ip_address, char* port);

#endif
