#include <stdio.h>

#include "server.h"
#include "log.h"
#include "user_connection.h"

#ifdef USE_MY_SAFE_STR_FUNCS

// From https://opensource.apple.com/source/xnu/xnu-4570.1.46/osfmk/arm/strlcpy.c.auto.html
size_t strlcpy(char * dst, const char * src, size_t maxlen)
{
    const size_t srclen = strlen(src);
    if (srclen + 1 < maxlen) {
        memcpy(dst, src, srclen + 1);
    } else if (maxlen != 0) {
        memcpy(dst, src, maxlen - 1);
        dst[maxlen-1] = '\0';
    }
    return srclen;
}

// From https://opensource.apple.com/source/Libc/Libc-997.1.1/string/strlcat.c.auto.html
size_t strlcat(char * restrict dst, const char * restrict src, size_t maxlen)
{
    const size_t srclen = strlen(src);
    const size_t dstlen = strnlen(dst, maxlen);
    if (dstlen == maxlen) return maxlen+srclen;
    if (srclen < maxlen-dstlen) {
        memcpy(dst+dstlen, src, srclen+1);
    } else {
        memcpy(dst+dstlen, src, maxlen-dstlen-1);
        dst[maxlen-1] = '\0';
    }
    return dstlen + srclen;
}

#endif

int read_server_configuration(struct server_ctx* ctx, char* file_name, char* server_to_run)
{
    int num_of_server = 0;
    char buff[MAX_LEN_SVR_CFG];

    FILE* fp = fopen(file_name, "r");

    while(fgets(buff, MAX_LEN_SVR_CFG, fp)) {

        // Remove CR/LF at the end before parsing.
        while(buff[strlen(buff) - 1] == '\n' || buff[strlen(buff) - 1] == '\r') {
            buff[strlen(buff) - 1] = '\0';
        }

        int param_count = 0;
        char** params = split_string(buff, ",", &param_count);
        if (param_count < 4) {
            chilog(WARNING, "Encouter a wrong server configuration.");
        } else {
            ++num_of_server;
            if (server_to_run != NULL && strcmp(server_to_run, params[0]) == 0) {
                ctx->server_name = strdup(params[0]);
                ctx->ip_address = strdup(params[1]);
                ctx->port = strdup(params[2]);
                ctx->sverpasswd = strdup(params[3]);

                chilog(WARNING, "Will start server:%s %s %s %s", params[0], params[1], params[2], params[3]);
            } else {
                struct irc_server* s = (struct irc_server*)calloc(1, sizeof(struct irc_server));
                strlcpy(s->server_name, params[0], sizeof(s->server_name));
                strlcpy(s->ip_address, params[1], sizeof(s->ip_address));
                strlcpy(s->port, params[2], sizeof(s->port));
                strlcpy(s->sverpasswd, params[3], sizeof(s->sverpasswd));
                s->server_socket = 0;
                pthread_mutex_lock(&ctx->servers_lock);
                HASH_ADD_STR(ctx->other_servers, server_name, s);
                pthread_mutex_unlock(&ctx->servers_lock);

                chilog(WARNING, "Add server cfg:%s %s %s %s", params[0], params[1], params[2], params[3]);
            }
        }

        for(int i = 0; i < param_count; ++i)
            free(params[i]);
    }

    fclose(fp);

    return num_of_server;
}

struct irc_server* get_irc_server(struct server_ctx* ctx, char* server_name)
{
    struct irc_server* s = NULL;
    pthread_mutex_lock(&ctx->servers_lock);
    HASH_FIND_STR(ctx->other_servers, server_name, s);
    pthread_mutex_unlock(&ctx->servers_lock);
    return s;
}

struct irc_server*  get_irc_server_by_socket(struct server_ctx* ctx, int socket)
{
    struct irc_server* s = NULL;
    pthread_mutex_lock(&ctx->servers_lock);
    for(s = ctx->other_servers; s != NULL; s = s->hh.next) {
        if (socket == s->server_socket)
            break;
    }
    pthread_mutex_unlock(&ctx->servers_lock);
    return s;
}

void update_irc_server(struct server_ctx* ctx, char* server_name, int socket)
{
    struct irc_server* s = NULL;
    pthread_mutex_lock(&ctx->servers_lock);
    HASH_FIND_STR(ctx->other_servers, server_name, s);
    if (s) {
        s->server_socket = socket;
    }
    pthread_mutex_unlock(&ctx->servers_lock);
}

void add_user(struct server_ctx* ctx, char* nick, int client_socket, bool local_user)
{
    pthread_mutex_lock(&ctx->users_lock);

    struct user *new_user = (struct user *)calloc(1, sizeof(struct user));
    strcpy(new_user->nickname, nick);
    new_user->client_socket = client_socket;
    strcpy(new_user->user_mode, "ao");
    new_user->away_message = NULL;
    new_user->is_local_user = local_user;
    HASH_ADD_STR(ctx->users, nickname, new_user);

    pthread_mutex_unlock(&ctx->users_lock);
    chilog(INFO, "register user %s", nick);
}


void update_user(struct server_ctx* ctx, char* nick, char* username, char *realname, char* host)
{
    pthread_mutex_lock(&ctx->users_lock);
    struct user* p_user = NULL;
    HASH_FIND_STR(ctx->users, nick, p_user);
    if (p_user != NULL) {
        strcpy(p_user->username, username);
        strcpy(p_user->realname, realname);
        strcpy(p_user->hostname, host);
    }
    pthread_mutex_unlock(&ctx->users_lock);
}

struct user* update_user_nick(struct server_ctx* ctx, int socket, char* old_nick, char* new_nick)
{
    struct user* old_user = find_user(ctx, old_nick);

    add_user(ctx, new_nick, socket, old_user != NULL ? old_user->is_local_user : true);
    struct user* new_user = find_user(ctx, new_nick);

    if (old_user != NULL) {
        update_user(ctx, new_nick, old_user->username, old_user->realname, old_user->hostname);
        del_user(ctx, old_nick);
    }

    return new_user;
}

void del_user(struct server_ctx* ctx, char* nick)
{
    pthread_mutex_lock(&ctx->users_lock);
    struct user* u = NULL;
    HASH_FIND_STR(ctx->users, nick, u);
    if (u != NULL) {
        chilog(INFO, "delete user %s", nick);
        HASH_DEL(ctx->users, u);
        free(u);
    }
    pthread_mutex_unlock(&ctx->users_lock);
}

struct user* find_user(struct server_ctx* ctx, char* nick)
{
    struct user* p_user = NULL;
    pthread_mutex_lock(&ctx->users_lock);
    HASH_FIND_STR(ctx->users, nick, p_user);
    pthread_mutex_unlock(&ctx->users_lock);
    return p_user;
}

struct user* find_user_by_username(struct server_ctx *ctx, char* username)
{
    pthread_mutex_lock(&ctx->users_lock);
    for(struct user* u = ctx->users; u != NULL; u = u->hh.next) {
        if (strcpy(username, u->username) != 0) {
            pthread_mutex_unlock(&ctx->users_lock);
            return u;
        }
    }
    pthread_mutex_unlock(&ctx->users_lock);
    return NULL;
}

void set_user_mode(struct server_ctx* ctx, struct user* u, bool set, char* mode, char* info)
{
    pthread_mutex_lock(&ctx->users_lock);

    strcpy(u->user_mode, mode);
    chilog(INFO, "MODE is %s", u->user_mode);
    pthread_mutex_unlock(&ctx->users_lock);
}


