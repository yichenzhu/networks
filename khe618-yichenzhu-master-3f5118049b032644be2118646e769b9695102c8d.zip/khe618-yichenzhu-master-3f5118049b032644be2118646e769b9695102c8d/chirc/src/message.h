#ifndef MESSAGE_H
#define MESSAGE_H

#include <stdbool.h>

/* message.c - Message functions
 *
 * sendall - sends all bytes taken into account mutexes
 * handle_message_PRIVMSG - handles PRIVMSG command
 * handle_message_TOPIC - handles TOPIC command
 * handle_message_OPER - handles OPER command
 * handles_message_AWAY - handles AWAY command
 * handles_message_LIST - handles LIST command
 * welcome_new_user - changes REPL message based on parsed commands and hosts
 * nickname_in_use - sees if nickname is in use
 * no_nickname - determines if there is no such nickname
 * no_such_channel - determines if there is no such channel
 * cannot_send_to_channel - determines if able to send to channel
 * user_not_in_channel - sees if user is not in channel
 * channel_privs_needed - sees if channel privs are needed
 * unknown_mode - changes to unknown mode
 * reply_error - see if there is a reply error
 * reply_RPL_NAMREPLY - handles RPL_NAMREPLY
 * reply_RPL_ENDOFNAMES - handles RPL_ENDOFNAMES
 * reply_PONG - handles PONG
 * reply_RPL_YOUREOPER -
 * reply_LUSERS - handles LUSER
 * reply_JOIN - handles JOIN
 * reply_LIST - handles LIST
 * reply_LISTEND - handles LISTEND
 * reply_WHOISUSER - handles WHOISUSER
 * reply_ENDOFWHOIS - handles ENDOFWHOIS
 * reply_WHOISSERVER - handles WHOISSERVER
 * reply_TOPIC - handles TOPIC
 * forward_TOPIC - forwards TOPIC
 * reply_PART - handles PART
 * reply_QUIT - handles QUIT
 * no_recipient - see if there are no recipients
 * no_text - see if there are no texts
 * no_user - see if there are no users
 * send_priv_message - sends private message
 * relay_nick - relays nickname
 * relay_QUIT - relays QUIT command
 * relay_mode - relays mode command
 * relay_nick_to_server - relays NICK command to server
 * relay_JOIN_to_users - relays JOIN command to user
 * relay_PRIVMSG_to_channel - relays PRIVMSG to channel
 * relay_PRIVMSG_to_irc_servers - relays PRIVMSG to IRC servers
 * handle_message_PASS - handles message PASS
 * handle_message_SERVER - handles message SERVER
 * reply_PASS_SERVER - handles PASS and SERVER in replies
 * handle_message_CONNECT - handles CONNECT message
 * send_PASS_SERVER - sends PASS and SERVER
 */

struct server_ctx;
struct user;

#define MAX_MSG_LEN        512
#define MSG_VAL_LEN        128
#define END_OF_MSG_TAG    "\r\n"

int sendall(int s, char *buf, int len, int flags, struct server_ctx* ctx);

/*
 * welcome_new_user - changes the REPL message based on parsed commands and
 * hosts
 *
 * socket: Logging level of the message
 *
 * server_host: server host name (or if NA, IP address)
 *
 * nickname: input of NICK command
 *
 * username: input of USER command
 *
 * client_host: client host name (or if NA, IP address)
 *
 * no_nickname: error sent when a nickname is not specified
 *
 * nickname_in_use: error sent when a nickname is already in use
 *
 * Returns: nothing.
 */
void welcome_new_user(struct server_ctx* ctx, int client_socket, const char*
                      nickname, const char* username, char* server_hostname, char *client_hostname);

/*
 * nickname_in_use - sees if nickname is in use
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * curr_nickname - current given nickname
 *
 * new_nickname - new nickname to change
 *
 * server_hostname - hostname of server
 *
 * Returns: nothing.
 */
void nickname_in_use(struct server_ctx* ctx, int client_socket, const char*
                     curr_nickname, const char* new_nickname, char* server_hostname);

/*
 * no_nickname - determines if there is no such nickname
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - given nickname
 *
 * server_hostname - hostname of server
 *
 * Returns: nothing.
 */
void no_nickname(struct server_ctx* ctx, int client_socket, char *nickname,
                 char *server_hostname);

/*
 * no_such_channel - determines if there is no such channel
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * server_hostname - hostname of server
 *
 * Returns: nothing.
 */
void no_such_channel(struct server_ctx* ctx, int client_socket,
                     char *nickname, char *channel_name, char *server_hostname);

/*
 * cannot_send_to_channel - determines if able to send to channel
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * Returns: nothing.
 */
void cannot_send_to_channel(struct server_ctx* ctx, int client_socket,
                            char *server_name, char *nickname, char *channel_name);

/*
 * user_not_in_channel - sees if user is not in channel
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * Returns: nothing.
 */
void user_not_in_channel(struct server_ctx* ctx, int client_socket,
                         char *nickname, char *channel_name, char *target, char *server_hostname);

/*
 * channel_privs_needed - sees if channel privs are needed
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * server_hostname - hostname of server
 *
 * mode - channel mode
 *
 * Returns: nothing.
 */
void channel_privs_needed(struct server_ctx* ctx, int client_socket,
                          char *nickname, char *channel_name, char *server_hostname);

/*
 * unknown_mode - changes to unknown mode
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * server_hostname - hostname of server
 *
 * mode - channel mode
 *
 * Returns: nothing.
 */
void unknown_mode(struct server_ctx* ctx, int client_socket,
                  char *nickname, char *channel_name, char *server_hostname, char mode);

/*
 * reply_error - reply with error
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - hostname of server
 *
 * error_code - code of error
 *
 * nickname - given nickname
 *
 * information - information for the server struct
 *
 * Returns: nothing.
 */
void reply_error(struct server_ctx* ctx, int client_socket,
                 char* server_hostname, char* error_code, char* nickname, char* information);

/*
 * reply_RPL_NAMREPLY - reply with name of reply
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - hostname of server
 *
 * nick_name - nickname
 *
 * Returns: nothing.
 */
void reply_RPL_NAMREPLY(struct server_ctx* ctx, int client_socket,
                        const char* server_hostname, const char* nick_name);

/*
 * reply_RPL_ENDOFNAMES - sends reply of end of names
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - hostname of server
 *
 * nick_name - given nickname
 *
 * Returns: nothing.
 */
void reply_RPL_ENDOFNAMES(struct server_ctx* ctx, int client_socket,
                          const char* server_hostname, const char* nick_name);

/*
 * reply_PONG - sends reply of PONG command
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * Returns: nothing.
 */
void reply_PONG(struct server_ctx* ctx, int client_socket,
                const char* server_name);

/*
 * reply_RPL_YOUREOPER - sends reply that you're operator
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - given nickname
 *
 * Returns: nothing.
 */
void reply_RPL_YOUREOPER(struct server_ctx* ctx, int client_socket,
                         const char* server_name, const char* nick);

/*
 * reply_LUSER - reply list of users
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - nickname
 *
 * users - number of users
 *
 * unknown - number of unknown
 *
 * clients - number of clients
 *
 * Returns: nothing.
 */
void reply_LUSERS(struct server_ctx* ctx, int client_socket,
                  const char* server_name, const char* nick, int users, int unknown, int clients);

/*
 * reply_JOIN - reply with JOIN
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - hostname of server
 *
 * channel - channel name
 *
 * nickname - given nickname
 *
 * username - given username
 *
 * client_host - client hostname
 *
 * Returns: nothing.
 */
void reply_JOIN(struct server_ctx* ctx, int client_socket,
                const char* server_hostname, const char* channel, const char* nickname,
                const char* username, const char* client_host);

/*
 * reply_LIST - reply with LIST
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * channel_name - name of channel
 *
 * num_users - number of users
 *
 * topic - topic of channel
 *
 * Returns - nothing.
 */
void reply_LIST(struct server_ctx* ctx, int client_socket, char* server_name,
                char* nickname, char *channel_name, int num_users, char *topic);

/*
 * reply_LISTEND - reply with end of list
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * Returns - nothing.
 */
void reply_LISTEND(struct server_ctx* ctx, int client_socket,
                   char* server_name, char* nickname);

/*
 * reply_WHOISUSER - reply with who the user is
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * user - given user
 *
 * Returns - nothing.
 */
void reply_WHOISUSER(struct server_ctx* ctx, int client_socket,
                     char* server_name, char *nickname, struct user *user);

/*
 * reply_ENDOFWHOIS - reply with end of user list
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nickname - given nickname
 *
 * name - name
 *
 * Returns - nothing.
 */
void reply_ENDOFWHOIS(struct server_ctx* ctx, int client_socket,
                      char *server_name, char *nickname, char *name);

/*
 * reply_WHOISSERVER - reply with who is the server
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * hostname - server hostname
 *
 * nickname - nickname
 *
 * name - given name
 *
 * Returns - nothing.
 */
void reply_WHOISSERVER(struct server_ctx* ctx, int client_socket,
                       char* server_name, char* hostname, char *nickname, char *name);

/*
 * reply_TOPIC - reply with topic
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - server hostname
 *
 * channel_name - name of channel
 *
 * nickname - nickname
 *
 * username - username
 *
 * topic - channel topic
 *
 * Returns - nothing.
 */
void reply_TOPIC(struct server_ctx* ctx, int client_socket,
                 const char* server_hostname, const char* channel_name,const char* nickname,
                 const char* username, const char* topic);

/*
 * forward_TOPIC - forwards TOPIC message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - server hostname
 *
 * channel_name - name of channel
 *
 * nickname - given nickname
 *
 * username - given username
 *
 * topic - channel topic
 *
 * Returns - nothing.
 */
void forward_TOPIC(struct server_ctx* ctx, int client_socket,
                   const char* server_hostname, const char* channel_name, const char* nickname,
                   const char* username, const char* topic);

/*
 * reply_PART - replies with PART command
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_hostname - server hostname
 *
 * channel - name of channel
 *
 * nickname - given nickname
 *
 * username - given username
 *
 * part_message - message from PART command
 *
 * Returns - nothing.
 */
void reply_PART(struct server_ctx* ctx, int client_socket,
                const char* server_hostname, const char* channel, const char* nickname,
                const char* username, const char* part_message);

/*
 * reply_QUIT - reply with QUIT message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * quit_message - quit message
 *
 * Returns - nothing.
 */
void reply_QUIT(struct server_ctx* ctx, int client_socket,
                const char* server_name, char* quit_message);

/*
 * no_recipient - see if there are no recipients
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - nickname
 *
 * Returns - nothing.
 */
void no_recipient(struct server_ctx* ctx, int client_socket,
                  const char *server_name, const char *nick);

/*
 * no_text - see if there are no texts
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - nickname
 *
 * Returns - nothing.
 */
void no_text(struct server_ctx* ctx, int client_socket,
             const char *server_name, const char *nick);

/*
 * no_user - see if there are no users
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - nickname
 *
 * recipient - recipient
 *
 * Returns - nothing.
 */
void no_user(struct server_ctx* ctx, int client_socket,
             const char *server_name, const char *nick, const char *recipient);

/*
 * send_priv_message - sends private message
 *
 * ctx - server struct
 *
 * sender - name of sender
 *
 * client_socket - client socket ID
 *
 * command - command
 *
 * target - name of target
 *
 * msg - message
 *
 * Returns - nothing.
 */
void send_priv_message(struct server_ctx* ctx, struct user *sender,
                       int client_socket, char *command, char *target, char *msg);

/*
 * relay_nick - relays nickname
 *
 * ctx - server struct
 *
 * sender - name of sender
 *
 * client_socket - client socket ID
 *
 * old_nickname - old nickname
 *
 * Returns - nothing.
 */
void relay_nick(struct server_ctx* ctx, struct user *sender,
                int client_socket, char *old_nickname);

/*
 * relay_nick_to_server - relays nickname to server
 *
 * ctx - server struct
 *
 * sender - name of sender
 *
 * client_socket - client socket ID
 *
 * old_nickname - old nickname
 *
 * Returns - nothing.
 */
void relay_nick_to_server(struct server_ctx* ctx, struct user *sender,
                          int client_socket, char *old_nickname);

/*
 * relay_JOIN_to_users - relays JOIN to users
 *
 * ctx - server struct
 *
 * channel - channel name
 *
 * nick - nickname of user
 *
 * uname - username of user
 *
 * hostname - server hostname
 *
 * Returns - nothing.
 */
void relay_JOIN_to_users(struct server_ctx* ctx, char* channel,
                         char* nick, char* uname, char* hostname);

/*
 * relay_JOIN_to_irc_servers - relays JOIN command to IRC servers
 *
 * ctx - server struct
 *
 * channel - channel name
 *
 * nick - nickname
 *
 * username - username
 *
 * hostname - server hostname
 *
 * Returns - nothing.
 */
void relay_JOIN_to_irc_servers(struct server_ctx* ctx, char* channel,
                               char* nick, char* uname, char* hostname);

/*
 * relay_PRIVMSG_to_channel - relays PRIVMSG to channel
 *
 * ctx - server struct
 *
 * from_nick - msg from nickname
 *
 * cname - channel name
 *
 * message- message buffer
 *
 * Returns - nothing.
 */
void relay_PRIVMSG_to_channel(struct server_ctx* ctx, char* from_nick,
                              char* cname, char* message);

/*
 * relay_PRIVMSG_to_user - relays PRIVMSG to user
 *
 * ctx - server struct
 *
 * from_nick - msg from nickname buffer
 *
 * to_user - msg to user buffer
 *
 * to_channel - msg to channel buffer
 *
 * message - message buffer
 *
 * Returns - nothing.
 */
void relay_PRIVMSG_to_user(struct server_ctx* ctx, char* from_nick,
                           struct user* to_user, char* to_channel, char* message);

/*
 * relay_PRIVMSG_to_irc_servers - relays PRIVMSG to irc servers
 *
 * ctx - server struct
 *
 * nick - nickname
 *
 * uname - username
 *
 * hostname - hostname
 *
 * channel - channel name
 *
 * message - message buffer
 *
 * Returns - nothing.
 */
void relay_PRIVMSG_to_irc_servers(struct server_ctx* ctx, char* nick,
                                  char* uname, char* hostname, char* channel, char* message);

/*
 * relay_QUIT - relays QUIT command
 *
 * ctx - server struct
 *
 * sender - sender user
 *
 * client_socket - client socket ID
 *
 * quit_message - message for QUIT command
 *
 * Returns - nothing.
 */
void relay_QUIT(struct server_ctx* ctx, struct user *sender,
                int client_socket, char *quit_message);

/*
 * relay_mode - relays channel mode
 *
 * ctx - server struct
 *
 * sender - sender user
 *
 * client_socket - client socket ID
 *
 * channel_name - name of channel
 *
 * mode - channel mode
 *
 * target - target of which to relay
 *
 * Returns - nothing.
 */
void relay_mode(struct server_ctx* ctx, struct user *sender,
                int client_socket, char *channel_name, char *mode, char *target);

/*
 * handle_message_PRIVMSG - handles PRIVMSG message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - server name
 *
 * nick - nickname
 *
 * user_name - username
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * Returns - nothing.
 */
void handle_message_PRIVMSG(struct server_ctx* ctx, int client_socket,
                            char* server_name, char* nick, char* user_name, int param_count, char** params);

/*
 * handle_message_TOPIC - handles TOPIC message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - server name
 *
 * nick - nickname
 *
 * user_name - username
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * Returns - nothing.
 */
void handle_message_TOPIC(struct server_ctx* ctx, int client_socket,
                          char* server_name, char* nick, char* user_name, int param_count, char** params);

/*
 * handle_message_OPER - handles operator message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nick - nickname
 *
 * user_name - username
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * Returns - nothing.
 */
void handle_message_OPER(struct server_ctx* ctx, int client_socket, char* nick,
                         char* user_name, int param_count, char** params);

/*
 * handle_message_AWAY - handles AWAY message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nick - nickname
 *
 * user_name - username
 *
 * param_counter - number of parameters
 *
 * params - params buffer
 *
 * Returns - nothing.
 */
void handle_message_AWAY(struct server_ctx* ctx, int client_socket, char* nick,
                         char* user_name, int param_count, char** params);

/*
 * handle_message_LIST - handles LIST message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * server_name - name of server
 *
 * nick - nickname
 *
 * user_name - username
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * Returns - nothing.
 */
void handle_message_LIST(struct server_ctx* ctx, int client_socket,
                         char* server_name, char* nick, char* user_name, int param_count, char** params);

/*
 * relay_nick_to_channels - relays nickname to channels
 *
 * ctx - server struct
 *
 * nickname - nickname
 *
 * current_user - struct of current user
 *
 * Returns - nothing.
 */
void relay_nick_to_channels(struct server_ctx *ctx, char *nickname,
                            struct user *current_user);

/*
 * relay_quit_to_channels - relays quit to channels
 *
 * ctx - server struct
 *
 * nickname - nickname
 *
 * current_user - struct of current user
 *
 * msg - message
 *
 * Returns - nothing.
 */
void relay_quit_to_channels(struct server_ctx *ctx, char *nickname,
                            struct user *current_user, char *msg);

/*
 * handle_priv_message - handles private message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - nicknaame
 *
 * username - username
 *
 * client_hostname - client's hostname
 *
 * current_user - struct of current user
 *
 * parameter_count - number of parameters
 *
 * parameter_array - array of parameters
 *
 * Returns - nothing.
 */
void handle_priv_message(struct server_ctx* ctx, int client_socket,
                         char *nickname, char *username, char *client_hostname,
                         struct user *current_user, int parameter_count, char ** parameter_array);

/*
 * handle_notice - handles notice command
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * nickname - nickname
 *
 * username - username
 *
 * client_hostname - client's hostname
 *
 * current_user - struct of current user
 *
 * parameter_count - number of parameters
 *
 * parameter_array - array of parameters
 *
 * Returns - nothing.
 */
void handle_notice(struct server_ctx* ctx, int client_socket, char *nickname,
                   char *username, char *client_hostname, struct user *current_user,
                   int parameter_count, char ** parameter_array);


// Server related functions

/*
 * handle_message_PASS - handles PASS message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * Returns - integer indicating success/failure.
 */
int handle_message_PASS(struct server_ctx* ctx, int client_socket, int param_count, char** params);

/*
 * handle_message_SERVER - handles SERVER message
 *
 * ctx - server struct
 *
 * client_socket - client_socket ID
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * peer_server_name - peer server name
 *
 * Returns - boolean indicating success/failure.
 */
bool handle_message_SERVER(struct server_ctx* ctx, int client_socket, int param_count, char** params, char* peer_server_name);

/*
 * reply_PASS_SERVER - replies PASS and SERVER messages
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * peer_server - peer server name
 *
 * Returns - nothing.
 */
void reply_PASS_SERVER(struct server_ctx* ctx, int client_socket, char* peer_server);

/*
 * handle_message_CONNECT - handles CONNECT message
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * param_count - number of parameters
 *
 * params - params buffer
 *
 * SERVER_registered - boolean to see if server is registered
 *
 * Returns - nothing.
 */
void handle_message_CONNECT(struct server_ctx* ctx, int client_socket, int param_count, char** params, bool *SERVER_registered);

/*
 * send_PASS_SERVER - sends PASS and SERVER messages
 *
 * ctx - server struct
 *
 * client_socket - client socket ID
 *
 * peer_server - peer server name
 *
 * Returns - nothing.
 */
void send_PASS_SERVER(struct server_ctx* ctx, int client_socket, char *peer_server);

#endif
