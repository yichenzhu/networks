#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>
#include <errno.h>

#include "user_connection.h"
#include "channel.h"
#include "message.h"
#include "log.h"
#include "reply.h"
#include "server.h"


int is_command(char *p_cmd)
{
    return strcmp("PRIVMSG", p_cmd) == 0 || strcmp("NOTICE", p_cmd) == 0 ||
           strcmp("PING", p_cmd) == 0 || strcmp("PONG", p_cmd) == 0 ||
           strcmp("LUSERS", p_cmd) == 0 || strcmp("WHOIS", p_cmd) == 0 ||
           strcmp("JOIN", p_cmd) == 0  || strcmp("PART", p_cmd) == 0 ||
           strcmp("AWAY", p_cmd) == 0 || strcmp("NAMES", p_cmd) == 0 ||
           strcmp("LIST", p_cmd) == 0;
}

/* We will use this struct to pass parameters to one of the threads */
struct worker_args {
    bool is_active_server;
    int socket;
    struct server_ctx *ctx;
};

char** split_string(char* str, char* delimiter, int* count)
{
    int cnt = 0;
    char** result_array = NULL;

    char* token;
    char* rest = str;
    char temp[MAX_MSG_LEN] = "";
    strcpy(temp, str);
    //ignore first character, since there is a colon in the header
    char* ptr = &temp[0];
    ptr++;

    while ((token = strtok_r(rest, delimiter, &rest))) {
        result_array = (char**)realloc(result_array, (cnt +1) * sizeof(char*));
        if (cnt > 0 && token[0] == ':') {
            for (; ptr[0] != ':'; ptr++);
            ptr++;
            //strcpy(result_array[cnt], ptr);
            *(result_array + cnt) = strdup(ptr);
            //chilog(INFO, "split found %s", result_array[cnt]);
            ++cnt;
            break;
        }
        *(result_array + cnt) = strdup(token);
        ++cnt;
    }

    if (count != NULL)
        *count = cnt;

    return result_array;
}


int get_msg_from_socket(int socket, char* buf, int buf_len)
{
    int msg_len = 0;
    int nbytes;
    char partial_msg[MAX_MSG_LEN] = "";

    do {
        if (((nbytes = recv(socket, partial_msg, sizeof(partial_msg) - 1, 0)) < 0)) {
            chilog(WARNING, "recv() failed, continue...");
            continue;
        }

        //If no messages are available to be received and the peer has
        //performed an orderly shutdown, recv() return 0.
        if (nbytes == 0)
            break;

        partial_msg[nbytes] = 0;
        msg_len += nbytes;

        strcat(buf, partial_msg);
        chilog(INFO, "sock=%d Receive msg='%s', nbytes=%d", socket, partial_msg, nbytes);
        memset(partial_msg, 0, sizeof(partial_msg));
    } while(strstr(buf, END_OF_MSG_TAG) == NULL);
    // Receive at least a whole message, break out to handle it.

    return msg_len;
}

void preserve_left_over_msg(char* left_over_msg, char* buf, int buf_len)
{
    if (strlen(left_over_msg) > 0) {
        chilog(INFO, "preserve the rest of message '%s' for next handling.", left_over_msg);
        char* temp = strdup(left_over_msg); // left_over_msg could point to the same memory as buf.
        memset(buf, 0, buf_len);
        strcpy(buf, temp);
        free(temp);
    } else {
        memset(buf, 0, buf_len);
    }
}

int process_user_connections(int server_socket, struct server_ctx* ctx)
{
    int client_socket;
    pthread_t worker_thread;
    struct sockaddr_storage *client_addr;
    struct worker_args *wa;
    socklen_t sin_size = sizeof(struct sockaddr_in);

    while(1) {
        client_addr = calloc(1, sin_size);
        if ((client_socket = accept(server_socket, (struct sockaddr *) client_addr, &sin_size)) == -1) {
            /* If this particular connection fails, no need to kill the entire thread. */
            free(client_addr);
            perror("Could not accept() connection");
            continue;
        }

        wa = calloc(1, sizeof(struct worker_args));
        wa->is_active_server = false;
        wa->socket = client_socket;
        wa->ctx = ctx;

        if (pthread_create(&worker_thread, NULL, service_single_client, wa) != 0) {
            perror("Could not create a worker thread");
            free(wa);
            free(client_addr);
            close(client_socket);
            close(server_socket);
            return EXIT_FAILURE;
        }

        free(client_addr);
    }

    return EXIT_SUCCESS;
}

void *service_single_client(void *args)
{
    /* Unpack the arguments */
    struct worker_args *wa = (struct worker_args*) args;
    int client_socket = wa->socket;
    struct server_ctx *ctx= wa->ctx;
    pthread_detach(pthread_self());
    char client_hostname[MAX_MSG_LEN];
    char service[20];
    struct sockaddr_in client_host;
    client_host.sin_family = AF_INET;
    socklen_t len;
    getpeername(client_socket, (struct sockaddr*)&client_host, &len);

    getnameinfo((struct sockaddr*)&client_host, sizeof client_host,
                client_hostname, sizeof client_hostname, service, sizeof service, 0);

    if (strlen(client_hostname) == 0)
        strcpy(client_hostname, "def-client-name");

    int *num_users = ctx->num_users;
    int *num_unknown = ctx->num_unknown;
    int *num_clients = ctx->num_clients;
    int *num_opers = ctx->num_opers;
    int *num_servers = ctx->num_servers;
    *num_unknown += 1;

    char nickname[MSG_VAL_LEN] = "*";
    char username[MSG_VAL_LEN] = "";
    char realname[MSG_VAL_LEN] = "";

    int NICK_received = 0;
    int USER_received = 0;
    int USER_registered = 0;
    int USER_quit = 0;

    bool PASS_received = false;
    bool SERVER_received = false;
    bool SERVER_registered = false;
    bool PASS_wrong = false;
    char peer_server_name[MAX_LEN_HOST_NAME] = "";

    int is_server = 0;
    int is_user = 0;

    char buffer[MAX_MSG_LEN] = "";
    struct user *current_user = NULL;

    char *server_name = ctx->server_name;


    while (!USER_quit) {
        int byte_received = get_msg_from_socket(client_socket, buffer, sizeof(buffer));
        if (byte_received == 0) {
            USER_quit = 1;
            chilog(INFO, "Client %s quit", nickname);
            if (is_server) {
                pthread_mutex_lock(&ctx->num_servers_lock);
                *num_clients -= 1;
                pthread_mutex_unlock(&ctx->num_servers_lock);
            } else if (is_user) {
                pthread_mutex_lock(&ctx->num_clients_lock);
                *num_clients -= 1;
                pthread_mutex_unlock(&ctx->num_clients_lock);
                if (USER_registered) {
                    pthread_mutex_lock(&ctx->num_users_lock);
                    *num_users -= 1;
                    pthread_mutex_unlock(&ctx->num_users_lock);
                    if (strcmp(current_user->user_mode, USER_MODE_OPERATOR)) {
                        pthread_mutex_lock(&ctx->num_opers_lock);
                        *num_opers -= 1;
                        pthread_mutex_unlock(&ctx->num_opers_lock);
                    }
                }
            } else {
                pthread_mutex_lock(&ctx->num_unknown_lock);
                *num_unknown -= 1;
                pthread_mutex_unlock(&ctx->num_unknown_lock);
            }
            continue;
        }

        char* p_msg = buffer;
        char* p_token = NULL;
        while (1) {
            // Locate the end of a message
            p_token = strstr(p_msg, END_OF_MSG_TAG);
            if (p_token == NULL) {
                preserve_left_over_msg(p_msg, buffer, sizeof(buffer));
                break;
            }

            // Copy the message to a buffer for handling
            int len = p_token - p_msg;
            char msg_buffer[MAX_MSG_LEN] = "";
            strncpy(msg_buffer, p_msg, len);
            msg_buffer[len] = 0;

            // Find the command in this message
            char* p_rest_msg = msg_buffer;
            char* p_cmd = strtok_r(p_rest_msg, " ", &p_rest_msg);
            if (p_cmd == NULL) {
                chilog(WARNING, "message(%s) doesn't have space delimiter?", msg_buffer);
                p_msg = p_token + sizeof(END_OF_MSG_TAG) - 1;
                continue;
            }

            // Since we need the whole string after QUIT, we check QUIT
            // command befor calling strtok_r again.
            if (USER_registered == 1 && strcmp("QUIT", p_cmd) == 0) {
                USER_quit = 1;
                reply_QUIT(ctx, client_socket, server_name, p_rest_msg);

                //relay QUIT to channels
                relay_quit_to_channels(ctx, nickname, current_user, p_rest_msg);

                pthread_mutex_lock(&ctx->num_clients_lock);
                *num_clients -= 1;
                pthread_mutex_unlock(&ctx->num_clients_lock);
                pthread_mutex_lock(&ctx->num_users_lock);
                *num_users -= 1;
                pthread_mutex_unlock(&ctx->num_users_lock);
                if (strcmp(current_user->user_mode, USER_MODE_OPERATOR)) {
                    pthread_mutex_lock(&ctx->num_opers_lock);
                    *num_opers -= 1;
                    pthread_mutex_unlock(&ctx->num_opers_lock);
                }
                break;
            }

            // Find the first parameter in this message
            int parameter_count = 0;
            char temp[MAX_MSG_LEN] = "";
            if (p_rest_msg != NULL) {
                strcpy(temp, p_rest_msg);

                // Remove CR/LF at the end before parsing.
                while(temp[strlen(temp) - 1] == '\n' || temp[strlen(temp) - 1] == '\r') {
                    temp[strlen(temp) - 1] = '\0';
                }
            }
            char** parameter_array = split_string(temp, " ", &parameter_count);

            // Processing commands
            if (strcmp("NICK", p_cmd) == 0) {
                if (parameter_count > 0) {
                    char* p_nick = parameter_array[0];
                    struct user* u = find_user(ctx, p_nick);
                    if (u != NULL) {
                        nickname_in_use(ctx, client_socket, nickname, p_nick, server_name);
                    } else {
                        current_user = update_user_nick(ctx, client_socket, nickname, p_nick);
                        NICK_received = 1;
                        relay_nick_to_channels(ctx, nickname, current_user);
                        strcpy(nickname, p_nick);
                        if (!is_user) {
                            is_user = 1;
                            pthread_mutex_lock(&ctx->num_unknown_lock);
                            *num_unknown -= 1;
                            pthread_mutex_unlock(&ctx->num_unknown_lock);
                            pthread_mutex_lock(&ctx->num_clients_lock);
                            *num_clients += 1;
                            pthread_mutex_unlock(&ctx->num_clients_lock);
                        }
                    }
                } else {
                    no_nickname(ctx, client_socket, nickname, server_name);
                }
            } else if (strcmp("USER", p_cmd) == 0) {
                if (parameter_count >= 4) {
                    USER_received = 1;
                    strcpy(username, parameter_array[0]);
                    strcpy(realname, parameter_array[3]);
                    chilog(INFO, "receive USER name=%s", username);
                    chilog(INFO, "receive real name=%s", realname);
                    if (!is_user) {
                        is_user = 1;
                        pthread_mutex_lock(&ctx->num_unknown_lock);
                        *num_unknown -= 1;
                        pthread_mutex_unlock(&ctx->num_unknown_lock);
                        pthread_mutex_lock(&ctx->num_clients_lock);
                        *num_clients += 1;
                        pthread_mutex_unlock(&ctx->num_clients_lock);
                    }
                } else {
                    char* info = "USER :Not enough parameters";
                    reply_error(ctx, client_socket, server_name,
                                ERR_NEEDMOREPARAMS, nickname, info);
                }
            } else if (strcmp("PASS", p_cmd) == 0) {
                if (SERVER_registered) {
                    struct irc_server* peer_sver = get_irc_server_by_socket(ctx, client_socket);
                    reply_error(ctx, client_socket, server_name, ERR_ALREADYREGISTRED,
                                peer_sver->server_name, ":Connection already registered");
                } else {
                    int result = handle_message_PASS(ctx, client_socket,
                                                     parameter_count, parameter_array);
                    if (result == 1) {
                        PASS_received = true;
                        PASS_wrong = false;
                    } else if (result == -1) {
                        PASS_wrong = true;
                    }
                }
                if (!is_server) {
                    is_server = 1;
                    pthread_mutex_lock(&ctx->num_unknown_lock);
                    *num_unknown -= 1;
                    pthread_mutex_unlock(&ctx->num_unknown_lock);
                    pthread_mutex_lock(&ctx->num_servers_lock);
                    *num_servers += 1;
                    pthread_mutex_unlock(&ctx->num_servers_lock);
                }
            } else if (strcmp("SERVER", p_cmd) == 0) {
                if (SERVER_registered) {
                    struct irc_server* peer_sver = get_irc_server_by_socket(ctx, client_socket);
                    reply_error(ctx, client_socket, server_name, ERR_ALREADYREGISTRED,
                                peer_sver->server_name, ":Connection already registered");
                } else {
                    SERVER_received = handle_message_SERVER(ctx, client_socket,
                                                            parameter_count, parameter_array, peer_server_name);
                    if (PASS_wrong) {
                        reply_error(ctx, client_socket, server_name,
                                    "ERROR"/*ERR_PASSWDMISMATCH*/, "", ":Bad password");
                    }
                }
                if (!is_server) {
                    is_server = 1;
                    pthread_mutex_lock(&ctx->num_unknown_lock);
                    *num_unknown -= 1;
                    pthread_mutex_unlock(&ctx->num_unknown_lock);
                    pthread_mutex_lock(&ctx->num_servers_lock);
                    *num_servers += 1;
                    pthread_mutex_unlock(&ctx->num_servers_lock);
                }

            } else {
                if (USER_registered == 0 && is_command(p_cmd)) {
                    char* info = ":You have not registered";
                    reply_error(ctx, client_socket, server_name,
                                ERR_NOTREGISTERED, nickname, info);
                } else if (strcmp("PRIVMSG", p_cmd) == 0) {
                    handle_priv_message(ctx, client_socket, nickname, username,
                                        client_hostname, current_user, parameter_count, parameter_array);
                } else if (strcmp("NOTICE", p_cmd) == 0) {
                    handle_notice(ctx, client_socket, nickname, username,
                                  client_hostname, current_user, parameter_count, parameter_array);
                } else if (strcmp("PING", p_cmd) == 0) {
                    reply_PONG(ctx, client_socket, server_name);
                } else if (strcmp("PONG", p_cmd) == 0) {
                    chilog(INFO, "Silently drop PONG message: %s", p_cmd, p_msg);
                } else if (strcmp("MOTD", p_cmd) == 0) {
                    reply_error(ctx, client_socket, server_name, ERR_NOMOTD,
                                nickname, ":MOTD File is missing");
                } else if (strcmp("LUSERS", p_cmd) == 0) {
                    reply_LUSERS(ctx, client_socket, server_name, nickname,
                                 *num_users, *num_unknown, *num_clients);
                } else if (strcmp("WHOIS", p_cmd) == 0) {
                    if (parameter_count > 0) {
                        char* p_nick = parameter_array[0];
                        struct user* u = find_user(ctx, p_nick);
                        if (u) {
                            reply_WHOISUSER(ctx, client_socket, server_name, nickname, u);
                            reply_WHOISSERVER(ctx, client_socket, server_name,
                                              u->hostname, nickname, p_nick);
                            reply_ENDOFWHOIS(ctx, client_socket, server_name, nickname, p_nick);
                        } else {
                            no_user(ctx, client_socket, server_name, nickname, p_nick);
                        }
                    }
                } else if (strcmp("JOIN", p_cmd) == 0) {
                    if (parameter_count <= 0) {
                        reply_error(ctx, client_socket, server_name,
                                    ERR_NEEDMOREPARAMS, nickname, "JOIN :Not enough parameters");
                    } else {
                        char* p_channels = parameter_array[0];
                        chilog(INFO, "Client requests to join %s", parameter_array[0]);

                        if (strcmp(p_channels, "0") == 0) {
                            // TODO: leaving all channels
                        } else {
                            int count = 0;
                            char** channel_array = split_string(p_channels, ",", &count);
                            for (int i = 0; i < count; ++i) {
                                char* channel = channel_array[i];
                                chilog(INFO, "JOINing channel %s", channel);
                                channel_info* ci = find_channel(ctx, channel);
                                if (ci == NULL) {
                                    if (strchr(channel, '#') != NULL) {
                                        // create a new channel
                                        add_channel(ctx, channel);
                                        ci = find_channel(ctx, channel);
                                        add_operator(ctx, ci, nickname);
                                    } else {
                                        char info[128] = "";
                                        sprintf(info, "%s :No such channel", channel);
                                        reply_error(ctx, client_socket, server_name,
                                                    ERR_NOSUCHCHANNEL, nickname, info);
                                    }
                                }

                                bool is_already_in_channel = is_user_in_channel(ctx, ci, nickname);
                                if (!is_already_in_channel) {
                                    add_user_to_channel(ctx, ci, current_user);

                                    reply_JOIN(ctx, client_socket, server_name, channel,
                                               nickname, username, server_name);

                                    if (ci->topic != NULL && strlen(ci->topic) > 0) {
                                        reply_TOPIC(ctx, client_socket, server_name, ci->name,
                                                    nickname, username, ci->topic);
                                    }

                                    reply_RPL_NAMREPLY(ctx, client_socket, server_name, nickname);
                                    reply_RPL_ENDOFNAMES(ctx, client_socket, server_name, nickname);

                                    relay_JOIN_to_users(ctx, channel, nickname, username, server_name);

                                    relay_JOIN_to_irc_servers(ctx, channel, nickname, username, server_name);
                                } else {
                                    chilog(INFO, "%s is already in channel %s", nickname, channel);
                                }

                                free(channel);  // free char* from split_string
                            }
                        }
                    }
                } else if (strcmp("PART", p_cmd) == 0) {
                    if (parameter_count <= 0) {
                        // Only accept either one parameter (a channel name) or
                        // two parameters (a channel name and a parting message)
                        reply_error(ctx, client_socket, server_name,
                                    ERR_NEEDMOREPARAMS, nickname, "PART :Not enough parameters");
                    } else {
                        char part_message[MAX_MSG_LEN] = "";
                        for (int i = 1; i < parameter_count; ++i) {
                            strcat(part_message, " ");
                            strcat(part_message, parameter_array[i]);
                        }

                        int count = 0;
                        char** channels = split_string(parameter_array[0], ",", &count);

                        for (int i = 0; i < count; ++i) {
                            channel_info* ci = find_channel(ctx, channels[i]);
                            if (ci == NULL) {
                                char info[128] = "";
                                sprintf(info, "%s :No such channel", channels[i]);
                                reply_error(ctx, client_socket, server_name,
                                            ERR_NOSUCHCHANNEL, nickname, info);
                                continue;
                            }

                            pthread_mutex_lock(&ctx->channels_lock);
                            struct user_in_channel* cu = NULL;
                            chilog(INFO, ">>>>>Relay PART to other users:");
                            for(cu = ci->channel_users; cu != NULL; cu = cu->hh.next) {
                                reply_PART(ctx, cu->client_socket, server_name, channels[i],
                                           nickname, username, part_message);
                            }
                            pthread_mutex_unlock(&ctx->channels_lock);
                            chilog(INFO, "<<<<<End of relay PART");

                            if (is_user_in_channel(ctx, ci, nickname)) {
                                //remove user from the channel
                                del_user_from_channel(ctx, ci, nickname);

                                // delete the channel if last user is left.
                                if (user_count_in_channel(ctx, ci) == 0) {
                                    del_channel(ctx, ci);
                                }
                            } else {
                                char info[128] = "";
                                sprintf(info, "%s :You're not on that channel", channels[i]);
                                reply_error(ctx, client_socket, server_name, ERR_NOTONCHANNEL, nickname,info);
                            }

                            free(channels[i]);
                        }
                    }
                } else if (strcmp("TOPIC", p_cmd) == 0) {
                    handle_message_TOPIC(ctx, client_socket, server_name, nickname,
                                         username, parameter_count, parameter_array);
                } else if (strcmp("OPER", p_cmd) == 0) {
                    handle_message_OPER(ctx, client_socket, nickname, username,
                                        parameter_count, parameter_array);
                } else if (strcmp("AWAY", p_cmd) == 0) {
                    handle_message_AWAY(ctx, client_socket, nickname, username,
                                        parameter_count, parameter_array);
                } else if (strcmp("NAMES", p_cmd) == 0) {
                    reply_RPL_NAMREPLY(ctx, client_socket, server_name, nickname);
                    reply_RPL_ENDOFNAMES(ctx, client_socket, server_name, nickname);
                } else if (strcmp("LIST", p_cmd) == 0) {
                    handle_message_LIST(ctx, client_socket, server_name, nickname,
                                        username, parameter_count, parameter_array);
                } else if (strcmp("OPER", p_cmd) == 0) {
                    handle_message_OPER(ctx, client_socket, nickname, username,
                                        parameter_count, parameter_array);
                } else if (strcmp("MODE", p_cmd) == 0) {
                    if (parameter_count >= 3) {
                        char *channel_name = parameter_array[0];
                        channel_info *channel = find_channel(ctx, channel_name);
                        if (channel) {
                            char *target = parameter_array[2];
                            if (is_user_in_channel(ctx, channel, target)) {
                                chilog(INFO, "MODE is %s", current_user->is_irc_operator);
                                if (is_user_channel_operator(ctx, channel, nickname) ||
                                        strcmp(find_user(ctx, nickname)->user_mode, USER_MODE_OPERATOR) == 0) {
                                    char *mode = parameter_array[1];
                                    if (strcmp(mode, "+o") == 0) {
                                        pthread_mutex_lock(&ctx->channels_lock);
                                        for(struct user_in_channel *channel_users = channel->channel_users;
                                                channel_users != NULL; channel_users=channel_users->hh.next) {
                                            relay_mode(ctx, current_user,
                                                       channel_users->client_socket, channel_name, mode, target);
                                        }
                                        pthread_mutex_unlock(&ctx->channels_lock);
                                        add_operator(ctx, channel, target);
                                    } else if (strcmp(mode, "-o") == 0) {
                                        delete_operator(ctx, channel, target);
                                    } else {
                                        unknown_mode(ctx, client_socket, nickname, channel_name, server_name, mode[1]);
                                    }

                                } else {
                                    channel_privs_needed(ctx, client_socket, nickname, channel_name, server_name);
                                }
                            } else {
                                user_not_in_channel(ctx, client_socket, nickname, channel_name, target, server_name);
                            }
                        } else {
                            no_such_channel(ctx, client_socket, nickname, channel_name, server_name);
                        }
                    }
                } else if (strcmp("CONNECT", p_cmd) == 0) {
                    handle_message_CONNECT(ctx, client_socket, parameter_count,
                                           parameter_array, &SERVER_registered);
                    chilog(INFO, "server registered %d", SERVER_registered);
                } else if (USER_registered) {
                    char err_info[128] = "";
                    sprintf(err_info, "%s :Unknown command", p_cmd);
                    reply_error(ctx, client_socket, server_name,
                                ERR_UNKNOWNCOMMAND, nickname, err_info);
                } else {
                    //we have received a message from another server
                    if (strcmp(parameter_array[0], "NICK") == 0) {
                        // Parameters: <nickname> <hopcount> <username> <host> <servertoken> <umode> <realname>
                        char* nname = parameter_array[1];
                        char* uname = parameter_array[3];
                        char* rname = parameter_array[7];
                        char* hname = parameter_array[4];
                        if (rname[0] == ':') {
                            rname++;
                        }
                        chilog(INFO, "HOSTNAME: %s", hname);
                        chilog(INFO, "nick from other server");
                        chilog(INFO, "realname: %s", rname);

                        add_user(ctx, nname, client_socket, false);
                        update_user(ctx, nname, uname, rname, hname);
                        pthread_mutex_lock(&ctx->num_users_lock);
                        *num_users += 1;
                        pthread_mutex_unlock(&ctx->num_users_lock);
                    } else if (strcmp("PASS", parameter_array[0]) == 0) {
                        if (SERVER_registered) {
                            struct irc_server* peer_sver = get_irc_server_by_socket(ctx, client_socket);
                            reply_error(ctx, client_socket, server_name, ERR_ALREADYREGISTRED,
                                        peer_sver->server_name, ":Connection already registered");
                        } else {
                            int result = handle_message_PASS(ctx, client_socket, parameter_count-1, parameter_array+1);
                            if (result == 1) {
                                PASS_received = true;
                                PASS_wrong = false;
                            } else if (result == -1) {
                                PASS_wrong = true;
                            }
                        }
                        if (!is_server) {
                            is_server = 1;
                            pthread_mutex_lock(&ctx->num_unknown_lock);
                            *num_unknown -= 1;
                            pthread_mutex_unlock(&ctx->num_unknown_lock);
                            pthread_mutex_lock(&ctx->num_servers_lock);
                            *num_servers += 1;
                            pthread_mutex_unlock(&ctx->num_servers_lock);
                        }
                    } else if (strcmp("SERVER", parameter_array[0]) == 0) {
                        if (SERVER_registered) {
                            struct irc_server* peer_sver = get_irc_server_by_socket(ctx, client_socket);
                            reply_error(ctx, client_socket, server_name, ERR_ALREADYREGISTRED,
                                        peer_sver->server_name, ":Connection already registered");
                        } else {
                            SERVER_received = handle_message_SERVER(ctx, client_socket,
                                                                    parameter_count-1, parameter_array+1, peer_server_name);
                            if (PASS_wrong) {
                                reply_error(ctx, client_socket, server_name, "ERROR", "", ":Bad password");
                            }
                        }
                        if (!is_server) {
                            is_server = 1;
                            pthread_mutex_lock(&ctx->num_unknown_lock);
                            *num_unknown -= 1;
                            pthread_mutex_unlock(&ctx->num_unknown_lock);
                            pthread_mutex_lock(&ctx->num_servers_lock);
                            *num_servers += 1;
                            pthread_mutex_unlock(&ctx->num_servers_lock);
                        }

                    } else if (strcmp("PRIVMSG", parameter_array[0]) == 0) {
                        chilog(INFO, "!!!!! PRIVMSG to be handled %s, %d, %s, %s",
                               p_cmd, parameter_count, parameter_array[1], p_rest_msg);
                        if (parameter_count >= 3) {
                            if (parameter_array[1][0] == '#') {    // A message to channel
                                char* from_user = p_cmd;
                                while(from_user[0] == ':')
                                    from_user++;
                                // Recompose the original message
                                char oriMsg[MAX_MSG_LEN] = "";
                                for(int i = 2; i < parameter_count; ++i) {
                                    if (i != 2)
                                        strlcat(oriMsg, " ", MAX_MSG_LEN);

                                    strlcat(oriMsg, parameter_array[i], MAX_MSG_LEN);
                                }

                                char* cname = parameter_array[1];
                                relay_PRIVMSG_to_channel(ctx, from_user, cname, oriMsg);

                            } else {    // A message to user
                                char* from_user = p_cmd;
                                while(from_user[0] == ':')
                                    from_user++;

                                char* to_user = parameter_array[1];
                                char* message = parameter_array[2];

                                struct user* u = find_user(ctx, to_user);
                                if (u != NULL) {
                                    relay_PRIVMSG_to_user(ctx, from_user, u, NULL, message);
                                }
                            }
                        }

                    } else if (strcmp("JOIN", parameter_array[0]) == 0) {
                        if (parameter_count >= 2) {
                            char* p_user = p_cmd;
                            while (p_user[0] == ':')
                                p_user++;
                            p_user = strtok(p_user, "!");

                            struct user* u = find_user(ctx, p_user);

                            char* cname = parameter_array[1];
                            relay_JOIN_to_users(ctx, cname, u->nickname, u->username, u->hostname);


                            chilog(INFO, "JOINing channel %s", cname);
                            channel_info* ci = find_channel(wa->ctx, cname);
                            if (ci == NULL) {
                                if (strchr(cname, '#') != NULL) {
                                    // create a new channel
                                    add_channel(ctx, cname);
                                    ci = find_channel(ctx, cname);
                                    add_operator(ctx, ci, p_user);
                                }
                            }
                            add_user_to_channel(ctx, ci, u);
                        }
                    }

                }
            }

            if (USER_registered == 0 && NICK_received == 1 && USER_received == 1) {
                USER_registered = 1;
                update_user(ctx, nickname, username, realname, server_name);
                pthread_mutex_lock(&ctx->num_users_lock);
                *num_users += 1;
                pthread_mutex_unlock(&ctx->num_users_lock);
                welcome_new_user(ctx, client_socket, nickname, username,
                                 server_name, server_name);
                reply_LUSERS(ctx, client_socket, server_name, nickname,
                             *num_users, *num_unknown, *num_clients);

                //relay nickname to other servers
                chilog(INFO, "other server=%d", HASH_COUNT(ctx->other_servers));
                for(struct irc_server* sver = ctx->other_servers;
                        sver != NULL; sver = sver->hh.next) {
                    if (sver->server_socket != 0) {
                        relay_nick_to_server(ctx, current_user,
                                             sver->server_socket, nickname);
                    }
                }
            }

            if (!SERVER_registered && PASS_received && SERVER_received) {
                SERVER_registered = true;
                reply_PASS_SERVER(ctx, client_socket, peer_server_name);
                update_irc_server(ctx, peer_server_name, client_socket);
                chilog(INFO, "update irc server");
            }

            // Free allocated parameters in this message
            for (int i = 0; i < parameter_count; ++i) {
                free(parameter_array[i]);
            }

            // continue to handle next message if there are more data
            p_msg = p_token + sizeof(END_OF_MSG_TAG) - 1;
        }
    }

    free(wa);
    close(client_socket);

    pthread_exit(NULL);
}


int connect_to_server(struct server_ctx* ctx, char* ip_address, char* port)
{
    int client_socket;

    struct addrinfo hints, // Used to provide hints to getaddrinfo()
               *res,  // Used to return the list of addrinfo's
               *p;    // Used to iterate over this list

    /* Buffer to receive bytes from the socket */
    char buffer[100 + 1]; // +1 for '\0'


    /* We want to leave all unused fields of hints to zero*/
    memset(&hints, 0, sizeof(hints));

    hints.ai_family = AF_UNSPEC;

    /* We want a reliable, full-duplex socket */
    hints.ai_socktype = SOCK_STREAM;

    /* Call getaddrinfo with the host and port specified in the command line */
    if (getaddrinfo(ip_address, port, &hints, &res) != 0) {
        chilog(INFO, "getaddrinfo failed");
        return -1;
    }

    /* Iterate through the list */
    for(p = res; p != NULL; p = p->ai_next) {
        /* Try to open a socket */
        if ((client_socket = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            perror("Could not open socket");
            continue;
        }

        if (connect(client_socket, p->ai_addr, p->ai_addrlen) == -1) {
            close(client_socket);
            perror("Could not connect to socket");
            continue;
        }
        break;

    }

    struct worker_args *wa;
    wa = calloc(1, sizeof(struct worker_args));
    wa->is_active_server = true;
    wa->socket = client_socket;
    wa->ctx = ctx;

    pthread_t worker_thread;
    if (pthread_create(&worker_thread, NULL, service_single_client, wa) != 0) {
        chilog(WARNING, "Could not create a worker thread");

        free(wa);
        close(client_socket);
        return EXIT_FAILURE;
    }

    freeaddrinfo(res);

    return client_socket;
    /* We don't need the linked list anymore. Free it. */

}

