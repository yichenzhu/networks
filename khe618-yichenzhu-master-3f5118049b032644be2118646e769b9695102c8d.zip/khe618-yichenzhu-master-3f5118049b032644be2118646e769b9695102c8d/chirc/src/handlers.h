#ifndef HANDLERS_H
#define HANDLERS_H

/*
 * handlers.c - Handler functions
 *
 * handle_nick: adds nickname to hash table if not currently used
 *
 */

/*
 * handle_nick - given information about the server, the function
 * adds nickname to hash table if not currently used
 *
 * ctx - information regarding the server. see server.h for full struct
 *
 * Returns: nothing.
 */
void handle_nick(struct context *ctx);

#endif
