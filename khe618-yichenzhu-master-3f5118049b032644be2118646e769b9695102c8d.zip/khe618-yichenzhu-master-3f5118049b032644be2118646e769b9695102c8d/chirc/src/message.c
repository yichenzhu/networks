#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <pthread.h>
#include "message.h"
#include "channel.h"
#include "server.h"
#include <time.h>
#include "log.h"
#include "reply.h"
#include "user_connection.h"

#define MAX_MSG_LEN 512

/*
 * welcome_new_user - changes the REPL message based on parsed commands and hosts
 *
 * socket: Logging level of the message
 *
 * server_host: server host name (or if NA, IP address)
 *
 * nickname: input of NICK command
 *
 * username: input of USER command
 *
 * client_host: client host name (or if NA, IP address)
 *
 * Returns: nothing.
 */

int sendall(int s, char *buf, int len, int flags, struct server_ctx* ctx)
{
    pthread_mutex_lock(&ctx->send_lock);
    int total = 0;        // how many bytes we've sent
    int bytesleft = len; // how many we have left to send
    int n;

    while(total < len) {
        n = send(s, buf+total, bytesleft, flags);
        if (n == -1) {
            break;
        }
        total += n;
        bytesleft -= n;
    }
    pthread_mutex_unlock(&ctx->send_lock);
    return n==-1 ? -1 : 0; // return -1 on failure, 0 on success
}


void welcome_new_user(struct server_ctx* ctx, int client_socket,const char* nickname,
                      const char* username, char* server_hostname, char *client_hostname)
{
    char *format = ":%s %s %s :Welcome to the Internet Relay Network %s!%s@%s\r\n";

    time_t rawtime;
    struct tm * timeinfo;
    time (&rawtime);
    timeinfo = localtime(&rawtime);
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, RPL_WELCOME, nickname, nickname, username, client_hostname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message: %s", send_buffer);

    char* host_info = ":%s %s %s :Your host is %s, running version %d\r\n";
    sprintf(send_buffer, host_info, server_hostname, RPL_YOURHOST, nickname, server_hostname, 1);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message: %s", send_buffer);

    char* created_info = ":%s %s %s :This server was created %s\r\n";
    sprintf(send_buffer, created_info, server_hostname, RPL_CREATED, nickname, asctime(timeinfo));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message: %s", send_buffer);

    char* my_info = ":%s %s %s %s %d %s %s\r\n";
    sprintf(send_buffer, my_info, server_hostname, RPL_MYINFO, nickname, server_hostname, 1, "ao", "mtov");
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message: %s", send_buffer);
}

void nickname_in_use(struct server_ctx* ctx, int client_socket, const char* curr_nickname,
                     const char* new_nickname, char* server_hostname)
{
    char *format = ":%s 433 %s %s :Nickname is already in use\r\n";
    char send_buffer[MAX_MSG_LEN];

    sprintf(send_buffer, format, server_hostname, curr_nickname, new_nickname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NICKNAMEINUSE(%s) message", send_buffer);
}

void user_not_in_channel(struct server_ctx* ctx, int client_socket, char *nickname,
                         char *channel_name, char *target, char *server_hostname)
{
    char *format = ":%s 441 %s %s %s :They aren't on that channel\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, nickname, target, channel_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_USERNOTINCHANNEL(%s) message", send_buffer);
}

void channel_privs_needed(struct server_ctx* ctx, int client_socket, char *nickname,
                          char *channel_name, char *server_hostname)
{
    char *format = ":%s 482 %s %s :You're not channel operator\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, nickname, channel_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_CHANOPRIVSNEEDED(%s) message", send_buffer);
}

void unknown_mode(struct server_ctx* ctx, int client_socket, char *nickname,
                  char *channel_name, char *server_hostname, char mode)
{
    char *format = ":%s 422 %s %c :is unknown mode char to me for %s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, nickname, mode, channel_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_UNKNOWNMODE(%s) message", send_buffer);
}


void no_nickname(struct server_ctx* ctx, int client_socket, char *nickname, char *server_hostname)
{
    char *format = ":%s 431 %s :No nickname given\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, nickname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NONICKNAMEGIVEN(%s) message", send_buffer);
}

void no_such_channel(struct server_ctx* ctx, int client_socket, char *nickname,
                     char *channel_name, char *server_hostname)
{
    char *format = ":%s 403 %s %s :No nickname given\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, nickname, channel_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NOSUCHCHANNEL(%s) message", send_buffer);
}

void reply_error(struct server_ctx* ctx, int client_socket, char* server_hostname,
                 char* error_code, char* nickname, char* information)
{
    char send_buffer[MAX_MSG_LEN];
    if (nickname != NULL && strlen(nickname) > 0)
        sprintf(send_buffer, ":%s %s %s %s\r\n", server_hostname, error_code, nickname, information);
    else
        sprintf(send_buffer, ":%s %s %s\r\n", server_hostname, error_code, information);

    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERROR message(%s)", send_buffer);
}

void reply_JOIN(struct server_ctx* ctx, int client_socket, const char* server_hostname,
                const char* channel, const char* nickname, const char* username, const char* client_host)
{
    char *format = ":%s!%s@%s JOIN %s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, nickname, username, client_host, channel);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send JOIN(%s) message", send_buffer);
}


void reply_PART(struct server_ctx* ctx, int client_socket, const char* server_hostname,
                const char* channel, const char* nickname, const char* username, const char* part_message)
{
    char *format = ":%s!%s@%s PART %s%s\r\n";
    // Note: no space between last two %s since we already have space from part_message !!!
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, nickname, username, server_hostname, channel, part_message);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send PART(%s) message", send_buffer);
}

void reply_TOPIC(struct server_ctx* ctx, int client_socket, const char* server_hostname,
                 const char* channel_name, const char* nickname, const char* username, const char* topic)
{
    char send_buffer[MAX_MSG_LEN];

    bool noTopic = topic == NULL || strlen(topic) == 0;

    char *format = ":%s!%s@%s %s %s %s%s\r\n";
    sprintf(send_buffer, format, nickname, username, server_hostname,
            (noTopic ? RPL_NOTOPIC : RPL_TOPIC), nickname, channel_name,
            (noTopic ? " :No topic is set" : topic));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send TOPIC(%s) message", send_buffer);
}

void forward_TOPIC(struct server_ctx* ctx, int client_socket, const char* server_hostname,
                   const char* channel_name, const char* nickname, const char* username, const char* topic)
{
    char *format = ":%s!%s@%s TOPIC %s%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, nickname, username, server_hostname, channel_name, topic);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "forward TOPIC(%s) message", send_buffer);
}

void reply_RPL_NAMREPLY(struct server_ctx* ctx, int client_socket,
                        const char* server_hostname, const char* nick_name)
{
    //Format:
    //"( "=" / "*" / "@" ) <channel>
    //:[ "@" / "+" ] <nick> *( " " [ "@" / "+" ] <nick> )
    char *format = ":%s %s %s = #foobar :foobar1 foobar2 foobar3\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, RPL_NAMREPLY, nick_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send RPL_NAMREPLY(%s) message", send_buffer);
}

void reply_RPL_ENDOFNAMES(struct server_ctx* ctx, int client_socket,
                          const char* server_hostname, const char* nick_name)
{
    //Format:
    //"( "=" / "*" / "@" ) <channel>
    //:[ "@" / "+" ] <nick> *( " " [ "@" / "+" ] <nick> )
    char *format = ":%s %s %s #foobar :End of NAMES list\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_hostname, RPL_ENDOFNAMES, nick_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send RPL_ENDOFNAMES(%s) message", send_buffer);
}


void reply_LUSERS(struct server_ctx* ctx, int client_socket, const char* server_name,
                  const char* nick, int users, int unknown, int clients)
{
//
//    :hostname 252 user1 0 :operator(s) online
//    :hostname 253 user1 0 :unknown connection(s)
//    :hostname 254 user1 0 :channels formed
//    :hostname 255 user1 :I have 1 clients and 1 servers
//    :hostname 422 user1 :MOTD File is missing

    char send_buffer[MAX_MSG_LEN];

    pthread_mutex_lock(&ctx->num_users_lock);
    pthread_mutex_lock(&ctx->num_servers_lock);
    char *format = ":%s %s %s :There are %d users and 0 services on %d servers\r\n";
    sprintf(send_buffer, format, server_name, RPL_LUSERCLIENT, nick, users, *(ctx->num_servers));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message: %s", send_buffer);
    pthread_mutex_unlock(&ctx->num_servers_lock);
    pthread_mutex_unlock(&ctx->num_users_lock);

    pthread_mutex_lock(&ctx->num_opers_lock);
    format = ":%s %s %s %d :operator(s) online\r\n";
    sprintf(send_buffer, format, server_name, RPL_LUSEROP, nick, *(ctx->num_opers));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message:%s", send_buffer);
    pthread_mutex_unlock(&ctx->num_opers_lock);

    pthread_mutex_lock(&ctx->num_unknown_lock);
    format = ":%s %s %s %d :unknown connection(s)\r\n";
    sprintf(send_buffer, format, server_name, RPL_LUSERUNKNOWN, nick, unknown);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message:%s", send_buffer);
    pthread_mutex_unlock(&ctx->num_unknown_lock);

    unsigned int channels = num_channels(ctx);
    format = ":%s %s %s %u :channels formed\r\n";
    sprintf(send_buffer, format, server_name, RPL_LUSERCHANNELS, nick, channels);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message:%s", send_buffer);

    pthread_mutex_lock(&ctx->num_clients_lock);
    pthread_mutex_lock(&ctx->num_servers_lock);
    format = ":%s %s %s :I have %d clients and %d servers\r\n";
    sprintf(send_buffer, format, server_name, RPL_LUSERME, nick, clients, *(ctx->num_servers)-1);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message:%s", send_buffer);
    pthread_mutex_unlock(&ctx->num_servers_lock);
    pthread_mutex_unlock(&ctx->num_clients_lock);


    format = ":%s %s %s :MOTD File is missing\r\n";
    sprintf(send_buffer, format, server_name, ERR_NOMOTD, nick);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message:%s", send_buffer);
}

void reply_PONG(struct server_ctx* ctx, int client_socket, const char* server_name)
{
    char *format = "PONG %s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message>", send_buffer);
}

void reply_RPL_YOUREOPER(struct server_ctx* ctx, int client_socket,
                         const char* server_name, const char* nick)
{
    char *format = ":%s %s %s :You are now an IRC operator\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, RPL_YOUREOPER, nick, ctx);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "RPL_YOUREOPER %s", nick);
}

void reply_QUIT(struct server_ctx* ctx, int client_socket,
                const char* server_name, char* quit_message)
{
    if (quit_message != NULL) {
        while (quit_message[0] == ' ') {
            quit_message++;
        }
        if (quit_message[0] == ':') {
            quit_message++;
        }
    }

    char *format = "ERROR :Closing Link: %s (%s)\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name,
            (quit_message != NULL && strlen(quit_message) > 0 ? quit_message : "Client Quit"));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message>%s", send_buffer);
}

void relay_JOIN_to_users(struct server_ctx* ctx, char* channel, char* nick, char* uname, char* hostname)
{
    chilog(INFO, ">>>>>Relay JOIN to other users: %s", channel);
    channel_info* ci = find_channel(ctx, channel);
    if (ci != NULL) {
        pthread_mutex_lock(&ctx->channels_lock);

        // Relay new user JOIN info to all other users in this channel
        struct user_in_channel* cu = NULL;
        for(cu = ci->channel_users; cu != NULL; cu = cu->hh.next) {
            // Only send to users other than just joined one.
            if (nick != NULL && strcmp(cu->nickname, nick) != 0) {
                reply_JOIN(ctx, cu->client_socket, ctx->server_name, channel,
                           nick, uname, hostname);
            }
        }

        pthread_mutex_unlock(&ctx->channels_lock);
    }
    chilog(INFO, "<<<<<End of relay JOIN");
}

void relay_JOIN_to_irc_servers(struct server_ctx* ctx, char* channel,
                               char* nick, char* uname, char* hostname)
{
    chilog(INFO, "Relay JOIN to irc_server(s)>>>>>");
    for(struct irc_server* sver = ctx->other_servers; sver != NULL; sver = sver->hh.next) {
        if (sver->server_socket != 0) {
            char send_buffer[MAX_MSG_LEN];
            sprintf(send_buffer, ":%s!%s@%s JOIN %s\r\n",
                    nick, uname, hostname, channel);
            sendall(sver->server_socket, send_buffer, strlen(send_buffer), 0, ctx);
            chilog(INFO, "send to %d JOIN(%s) message", sver->server_socket, send_buffer);
        }
    }
    chilog(INFO, "<<<<<relay_JOIN_to_irc_servers");
}

void relay_PRIVMSG_to_channel(struct server_ctx* ctx, char* from_nick, char* cname, char* message)
{
    chilog(INFO, "Relay PRIVMSG to channel %s>>>>>", cname);
    channel_info* ci = find_channel(ctx, cname);
    if (ci != NULL) {
        for(struct user_in_channel *channel_users = ci->channel_users;
                channel_users != NULL; channel_users=channel_users->hh.next) {
            if (strcmp(channel_users->nickname, from_nick) != 0) {
                struct user* u = find_user(ctx, channel_users->nickname);
                relay_PRIVMSG_to_user(ctx, from_nick, u, cname, message);
            }
        }
    }
    chilog(INFO, "<<<<<relay_PRIVMSG_to_channel");
}

void relay_PRIVMSG_to_user(struct server_ctx* ctx, char* from_nick,
                           struct user* to_user, char* to_channel, char* message)
{
    chilog(INFO, "Relay PRIVMSG to user>>>>>");
    if (to_user != NULL) {
        char send_buffer[MAX_MSG_LEN];
        sprintf(send_buffer, ":%s PRIVMSG %s :%s\r\n", from_nick,
                (to_channel != NULL ? to_channel : to_user->nickname), message);
        sendall(to_user->client_socket, send_buffer, strlen(send_buffer), 0, ctx);
        chilog(INFO, "send to %d PRIVMSG(%s) message", to_user->client_socket, send_buffer);
    }
    chilog(INFO, "<<<<<relay_PRIVMSG_to_user");
}

void relay_PRIVMSG_to_irc_servers(struct server_ctx* ctx, char* nick, char* uname,
                                  char* hostname, char* channel, char* message)
{
    chilog(INFO, "Relay PRIVMSG to irc_server(s)>>>>>");
    for(struct irc_server* sver = ctx->other_servers; sver != NULL; sver = sver->hh.next) {
        if (sver->server_socket != 0) {
            char send_buffer[MAX_MSG_LEN];
            sprintf(send_buffer, ":%s!%s@%s PRIVMSG %s :%s\r\n",
                    nick, uname, hostname, channel, message);
            sendall(sver->server_socket, send_buffer, strlen(send_buffer), 0, ctx);
            chilog(INFO, "send to %d PRIVMSG(%s) message", sver->server_socket, send_buffer);
        }
    }
    chilog(INFO, "<<<<<relay_PRIVMSG_to_irc_servers");
}

void relay_QUIT(struct server_ctx* ctx, struct user *sender,
                int client_socket, char *quit_message)
{
    if (quit_message != NULL) {
        while (quit_message[0] == ' ') {
            quit_message++;
        }
        if (quit_message[0] == ':') {
            quit_message++;
        }
    }
    char *format = ":%s!%s@%s QUIT :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, sender->nickname, sender->username, sender->hostname,
            (quit_message != NULL && strlen(quit_message) > 0 ? quit_message : "Client Quit"));
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send message>%s", send_buffer);
}

void reply_WHOISUSER(struct server_ctx* ctx, int client_socket, char* server_name, char *nickname, struct user *user)
{
    char *format = ":%s 311 %s %s %s %s * :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname, user->nickname,
            user->username, user->hostname, user->realname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send WHOISUSER(%s) message", send_buffer);

}

void reply_WHOISSERVER(struct server_ctx* ctx, int client_socket, char* server_name,
                       char* hostname, char *nickname, char *name)
{
    char *format = ":%s 312 %s %s %s :chirc-0.5.0\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname, name, hostname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send WHOISSERVER(%s) message", send_buffer);

}

void reply_LIST(struct server_ctx* ctx, int client_socket, char* server_name,
                char* nickname, char *channel_name, int num_users, char *topic)
{
    char *format = ":%s 322 %s %s %d :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname, channel_name, num_users, topic);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send RPL_LIST(%s) message", send_buffer);
}

void reply_LISTEND(struct server_ctx* ctx, int client_socket,
                   char* server_name, char* nickname)
{
    char *format = ":%s 323 %s :End of LIST\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send RPL_LISTEND(%s) message", send_buffer);
}



void cannot_send_to_channel(struct server_ctx* ctx, int client_socket,
                            char *server_name, char *nickname, char *channel_name)
{
    char *format = ":%s 404 %s %s :Cannot send to channel\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname, channel_name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_CANNOTSENDTOCHAN(%s) message", send_buffer);
}


void reply_ENDOFWHOIS(struct server_ctx* ctx, int client_socket, char *server_name,
                      char *nickname, char *name)
{
    char *format = ":%s 318 %s %s :End of WHOIS list\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nickname, name);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ENDOFWHOIS(%s) message", send_buffer);
}

void no_recipient(struct server_ctx* ctx, int client_socket,
                  const char *server_name, const char *nick)
{
    char *format = ":%s 411 %s :No recipient given (PRIVMSG)\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nick);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NORECIPIENT(%s) message", send_buffer);
}

void no_text(struct server_ctx* ctx, int client_socket,
             const char *server_name, const char *nick)
{
    char *format = ":%s 412 %s :No text to send\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nick);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NOTEXTTOSEND(%s) message", send_buffer);
}

void no_user(struct server_ctx* ctx, int client_socket, const char *server_name,
             const char *nick, const char *recipient)
{
    char *format = ":%s 401 %s %s :No such nick/channel\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, server_name, nick, recipient);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send ERR_NOTEXTTOSEND(%s) message", send_buffer);
}

void send_priv_message(struct server_ctx* ctx, struct user *sender,
                       int client_socket, char *command, char *target, char *msg)
{
    char *format = ":%s!%s@%s %s %s :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, sender->nickname, sender->username,
            sender->hostname, command, target, msg);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send private(%s) message", send_buffer);

}

void relay_nick(struct server_ctx* ctx, struct user *sender, int client_socket,
                char *old_nickname)
{
    char *format = ":%s!%s@%s NICK :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, old_nickname,
            strlen(sender->username) > 0 ? sender->username : "default_user",
            strlen(sender->hostname) > 0 ? sender->hostname : "default-host", sender->nickname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send relay nick(%s) message", send_buffer);
}

void relay_nick_to_server(struct server_ctx* ctx, struct user *sender,
                          int client_socket, char *nickname)
{
    char *format = ":%s!%s@%s NICK %s 1 %s %s 1 + :%s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, nickname, sender->username, ctx->server_name,
            sender->nickname, sender->username, ctx->server_name, sender->realname);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send relay nick(%s) message", send_buffer);
}


void relay_mode(struct server_ctx* ctx, struct user *sender, int client_socket,
                char *channel_name, char *mode, char *target)
{
    char *format = ":%s!%s@%s MODE %s %s %s\r\n";
    char send_buffer[MAX_MSG_LEN];
    sprintf(send_buffer, format, sender->nickname, sender->username,
            sender->hostname, channel_name, mode, target);
    sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
    chilog(INFO, "send relay mode(%s) message", send_buffer);
}

/////////////////////////////////////////
// Handle received messages
void send_TOPIC_to_all_channel_users(struct server_ctx* ctx, channel_info* ci,
                                     char* server_name, char* nick, char* user_name, char* topic)
{
    pthread_mutex_lock(&ctx->channels_lock);
    struct user_in_channel* cu = NULL;
    for(cu = ci->channel_users; cu != NULL; cu = cu->hh.next) {
        forward_TOPIC(ctx, cu->client_socket, server_name, ci->name, nick, user_name, topic);
    }
    pthread_mutex_unlock(&ctx->channels_lock);
}

void handle_message_TOPIC(struct server_ctx* ctx, int client_socket,
                          char* server_name, char* nick, char* user_name, int param_count, char** params)
{
    if (param_count > 0) {
        char* channel_name = params[0];
        channel_info* ci = find_channel(ctx, channel_name);
        if (ci == NULL || !is_user_in_channel(ctx, ci, nick)) {
            char info[128] = "";
            sprintf(info, "%s :You're not on that channel", channel_name);
            reply_error(ctx, client_socket, server_name, ERR_NOTONCHANNEL, nick, info);
            return;
        }

        if (param_count == 1) {
            reply_TOPIC(ctx, client_socket, server_name, ci->name, nick, user_name, ci->topic);
        } else {
            char topic[MAX_MSG_LEN] = "";
            for(int i = 1; i < param_count; ++i) {
                strcat(topic, " ");
                strcat(topic, params[i]);
            }

            if (ci != NULL) {
                if (strcmp(topic, ":") == 0) {
                    // This is to clear topic
                    topic[0] = '\0';
                }

                update_channel_topic(ctx, ci, topic);

                send_TOPIC_to_all_channel_users(ctx, ci, server_name, nick, user_name, topic);
            }
        }
    } else {
        reply_error(ctx, client_socket, server_name,
                    ERR_NEEDMOREPARAMS, nick, "TOPIC :Not enough parameters");
    }
}


void handle_message_OPER(struct server_ctx* ctx, int client_socket, char* nick,
                         char* user_name, int param_count, char** params)
{
    chilog(INFO, "username is %s, nickname is %s", user_name, nick);
    struct user* oper_user = find_user(ctx, nick);
    if (oper_user != NULL) {
        if (param_count >= 2) {
            char* username = params[0];
            char* password = params[1];
            struct user* u = find_user_by_username(ctx, username);
            if (strcmp(password, ctx->operpasswd) == 0) {
                //set_irc_operator(ctx, u, 1);
                set_user_mode(ctx, u, true, USER_MODE_OPERATOR, NULL);
                pthread_mutex_lock(&ctx->num_opers_lock);
                *(ctx->num_opers) += 1;
                pthread_mutex_unlock(&ctx->num_opers_lock);

                reply_RPL_YOUREOPER(ctx, client_socket, ctx->server_name, nick);
            } else {
                reply_error(ctx, client_socket, ctx->server_name,
                            ERR_PASSWDMISMATCH, nick, ":Password incorrect");
            }
        } else {
            reply_error(ctx, client_socket, ctx->server_name, ERR_NEEDMOREPARAMS,
                        nick, "OPER :Not enough parameters");
        }
    }
}


void handle_message_AWAY(struct server_ctx* ctx, int client_socket, char* nick,
                         char* user_name, int param_count, char** params)
{
    char send_buffer[MAX_MSG_LEN] = "";
    struct user* u = find_user(ctx, nick);
    if (u != NULL) {
        if (param_count > 0) {
            // concatenate away message back into a whole string
            char buffer[MAX_MSG_LEN] = "";
            for (int i = 0; i < param_count; ++i) {
                if (i != 0)
                    strcat(buffer, " ");

                strcat(buffer, params[i]);
            }

            set_user_mode(ctx, u, true, USER_MODE_AWAY, params[0]);
            char *format = ":%s %s %s :You have been marked as being away\r\n";
            sprintf(send_buffer, format, ctx->server_name, RPL_NOWAWAY, nick);
            sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
            chilog(INFO, "send message>%s", send_buffer);
        } else {
            set_user_mode(ctx, u, false, USER_MODE_AWAY, NULL);

            char *format = ":%s %s %s :You are no longer marked as being away\r\n";
            sprintf(send_buffer, format, ctx->server_name, RPL_UNAWAY, nick);
            sendall(client_socket, send_buffer, strlen(send_buffer), 0, ctx);
            chilog(INFO, "send message>%s", send_buffer);
        }
    }
}



void handle_message_LIST(struct server_ctx* ctx, int client_socket,
                         char* server_name, char* nick, char* user_name, int param_count, char** params)
{
    chilog(INFO, "handle_message_LIST>%s", nick);
    char info[MAX_MSG_LEN] = "";

    if (param_count > 0) {
        char* channel_name = params[0];
        channel_info* ci = find_channel(ctx, channel_name);
        if (ci) {
            reply_LIST(ctx, client_socket, ctx->server_name, nick, channel_name,
                       user_count_in_channel(ctx, ci), ci->topic);
        }
        chilog(INFO, "send message>%s", info);
    } else {
        int buf_len = MAX_MSG_LEN;
        char* buffer = (char*)calloc(sizeof(char), buf_len);
        sprintf(buffer, ":%s %s %s ", ctx->server_name, RPL_LIST, nick);
        channel_info* ci = NULL;
        pthread_mutex_lock(&ctx->channels_lock);
        for(ci = ctx->channels; ci != NULL; ci = ci->hh.next) {
            reply_LIST(ctx, client_socket, ctx->server_name, nick, ci->name,
                       HASH_COUNT(ci->channel_users), ci->topic);
        }
        pthread_mutex_unlock(&ctx->channels_lock);
    }

    reply_LISTEND(ctx, client_socket, ctx->server_name, nick);
    chilog(INFO, "send message>%s", info);
}


int handle_message_PASS(struct server_ctx* ctx, int client_socket, int param_count, char** params)
{
    int result = 0;
    if (param_count >= 3) {
        char* passwd = params[0];

        if (strcmp(passwd, ctx->sverpasswd) == 0) {
            result = 1;
        } else {
            chilog(WARNING, "Wrong password, no reply!!! passwd='%s' sverpasswd='%s'", passwd, ctx->sverpasswd);
            result = -1;
        }
    } else {
        reply_error(ctx, client_socket, ctx->server_name, ERR_NEEDMOREPARAMS, "", "PASS :Not enough parameters");
    }

    return result;
}

bool handle_message_SERVER(struct server_ctx* ctx, int client_socket,
                           int param_count, char** params, char* peer_server_name)
{
    bool result = false;
    if (param_count >= 2) {
        char* sname = params[0];
        struct irc_server* sver = get_irc_server(ctx, sname);
        if (sver != NULL) {
            if (sver->server_socket == 0) {
                result = true;
                strlcpy(peer_server_name, sname, MAX_LEN_HOST_NAME);
            } else {
                char info[MAX_MSG_LEN] = "";
                snprintf(info, MAX_MSG_LEN, ":ID \"%s\" already registered", sname);
                reply_error(ctx, client_socket, ctx->server_name, "ERROR", "", info);
            }
        } else {
            reply_error(ctx, client_socket, ctx->server_name, "ERROR", "", ":Server not configured here");
        }
    } else {
        reply_error(ctx, client_socket, ctx->server_name, ERR_NEEDMOREPARAMS, "", "SERVER :Not enough parameters");
    }

    return result;
}

void reply_PASS_SERVER(struct server_ctx* ctx, int client_socket, char* peer_server)
{
//    :irc-1.example.net PASS pass2 0210 chirc|0.5.1
//    :irc-1.example.net SERVER irc-1.example.net 1 :chirc server
    struct irc_server* sver = get_irc_server(ctx, peer_server);
    sver->server_socket = client_socket;    // To indicate server is connected.

    char buffer[MAX_MSG_LEN];
    snprintf(buffer, MAX_MSG_LEN, ":%s PASS %s 0210 chirc|0.5.1\r\n", ctx->server_name, sver->sverpasswd);
    sendall(client_socket, buffer, strlen(buffer), 0, ctx);
    chilog(INFO, "send message>%s", buffer);

    snprintf(buffer, MAX_MSG_LEN, ":%s SERVER %s 1 :chirc server\r\n", ctx->server_name, ctx->server_name);
    sendall(client_socket, buffer, strlen(buffer), 0, ctx);
    chilog(INFO, "send message>%s", buffer);
}

void send_PASS_SERVER(struct server_ctx* ctx, int client_socket, char *peer_server)
{
//    :irc-1.example.net PASS pass2 0210 chirc|0.5.1
//    :irc-1.example.net SERVER irc-1.example.net 1 :chirc server
    struct irc_server* sver = get_irc_server(ctx, peer_server);
    //sver->server_socket = client_socket;    // To indicate server is connected.
    chilog(INFO, "server name: %s", sver->server_name);
    char buffer[MAX_MSG_LEN];
    snprintf(buffer, MAX_MSG_LEN, "PASS %s 0210 chirc|0.5.1\r\n", sver->sverpasswd);
    sendall(client_socket, buffer, strlen(buffer), 0, ctx);
    chilog(INFO, "send message>%s", buffer);

    snprintf(buffer, MAX_MSG_LEN, "SERVER %s 1 :chirc server\r\n", ctx->server_name);
    sendall(client_socket, buffer, strlen(buffer), 0, ctx);
    chilog(INFO, "send message>%s", buffer);
}

void handle_message_CONNECT(struct server_ctx* ctx, int client_socket,
                            int param_count, char** params, bool *SERVER_registered)
{
    if (param_count >= 2) {
        char* target_server = params[0];
        //char* target_port = params[1];

        bool isOperator = true; //TODO:
        if (isOperator) {
            struct irc_server* sver = get_irc_server(ctx, target_server);
            if (sver != NULL) {
                chilog(INFO, "try to connect to server %s", target_server);
                int sockfd = connect_to_server(ctx, sver->ip_address, sver->port);
                send_PASS_SERVER(ctx, sockfd, target_server);
                if (sockfd > 0) {
                    chilog(INFO, "successfully connected");
                    update_irc_server(ctx, target_server, sockfd);
                    *SERVER_registered = 1;
                }

            } else {
                reply_error(ctx, client_socket, target_server, "", "", "ERROR :Server not configured here");
            }
        } else {
            reply_error(ctx, client_socket, ctx->server_name, ERR_NOPRIVILEGES,
                        "", ":Permission Denied- You're not an IRC operator");
        }
    } else {
        reply_error(ctx, client_socket, ctx->server_name, ERR_NEEDMOREPARAMS,
                    "", "CONNECT :Not enough parameters");
    }
}

void handle_priv_message(struct server_ctx* ctx, int client_socket, char *nickname,
                         char *username, char *client_hostname, struct user *current_user,
                         int parameter_count, char ** parameter_array)
{
    if (parameter_count > 0) {
        if (parameter_count > 1) {
            if (parameter_array[0][0] == '#') {
                //send to channel
                char *channel = parameter_array[0];
                channel_info* ci = find_channel(ctx, channel);
                if (ci) {
                    //check that user is in channel
                    if(is_user_in_channel(ctx, ci, nickname)) {
                        chilog(INFO, "Relay PRIVMSG to other users in channel>>>>>");
                        pthread_mutex_lock(&ctx->channels_lock);
                        for(struct user_in_channel *channel_users = ci->channel_users;
                                channel_users != NULL; channel_users=channel_users->hh.next) {
                            if (strcmp(channel_users->nickname, nickname) != 0) {
                                send_priv_message(ctx, current_user,
                                                  channel_users->client_socket, "PRIVMSG", channel, parameter_array[1]);
                            }
                        }
                        pthread_mutex_unlock(&ctx->channels_lock);
                        chilog(INFO, "<<<<< End of relaying PRIVMSG");
                        relay_PRIVMSG_to_irc_servers(ctx, nickname, username,
                                                     client_hostname, channel, parameter_array[1]);
                    } else {
                        cannot_send_to_channel(ctx, client_socket,
                                               ctx->server_name, nickname, channel);
                    }
                } else {
                    no_user(ctx, client_socket, ctx->server_name, nickname, channel);
                }
            } else {
                //send to recipient
                struct user *recipient = find_user(ctx, parameter_array[0]);
                if (recipient) {
                    send_priv_message(ctx, current_user, recipient->client_socket,
                                      "PRIVMSG", recipient->nickname, parameter_array[1]);
                } else {
                    no_user(ctx, client_socket, ctx->server_name, nickname, parameter_array[0]);
                }
            }
        } else {
            no_text(ctx, client_socket, ctx->server_name, nickname);
        }
    } else {
        no_recipient(ctx, client_socket, ctx->server_name, nickname);
    }
}

void handle_notice(struct server_ctx* ctx, int client_socket, char *nickname,
                   char *username, char *client_hostname, struct user *current_user,
                   int parameter_count, char ** parameter_array)
{
    if (parameter_count > 0) {
        if (parameter_count > 1) {
            if (parameter_array[0][0] == '#') {
                //send to channel
                char *channel = parameter_array[0];
                channel_info* ci = find_channel(ctx, channel);
                if (ci) {
                    //check that user is in channel
                    chilog(INFO, "%d users in channel", user_count_in_channel(ctx, ci));
                    if(is_user_in_channel(ctx, ci, nickname)) {
                        pthread_mutex_lock(&ctx->channels_lock);
                        for(struct user_in_channel *channel_users = ci->channel_users;
                                channel_users != NULL; channel_users=channel_users->hh.next) {
                            if (strcmp(channel_users->nickname, nickname) != 0) {
                                send_priv_message(ctx, current_user,
                                                  channel_users->client_socket, "NOTICE",
                                                  channel, parameter_array[1]);
                            }
                        }
                        pthread_mutex_unlock(&ctx->channels_lock);
                    }

                }
            } else {
                //send to recipient
                struct user *recipient = find_user(ctx, parameter_array[0]);
                if (recipient) {
                    send_priv_message(ctx, current_user, recipient->client_socket,
                                      "NOTICE", recipient->nickname, parameter_array[1]);
                }
            }
        }
    }
}

void relay_nick_to_channels(struct server_ctx *ctx, char *nickname, struct user *current_user)
{
    pthread_mutex_lock(&ctx->channels_lock);
    for(channel_info *ci = ctx->channels; ci != NULL; ci = ci->hh.next) {
        struct user_in_channel* cu = NULL;
        HASH_FIND_STR(ci->channel_users, nickname, cu);
        if (cu) {
            for(struct user_in_channel *channel_users = ci->channel_users;
                    channel_users != NULL; channel_users=channel_users->hh.next) {
                relay_nick(ctx, current_user, channel_users->client_socket, nickname);
            }
            HASH_DEL(ci->channel_users, cu);
            cu = (struct user_in_channel*)calloc(1, sizeof(struct user_in_channel));
            strcpy(cu->nickname, current_user->nickname);
            cu->client_socket = current_user->client_socket;
            HASH_ADD_STR(ci->channel_users, nickname, cu);
        }
    }
    pthread_mutex_unlock(&ctx->channels_lock);
}

void relay_quit_to_channels(struct server_ctx *ctx, char *nickname, struct user *current_user, char *msg)
{
    pthread_mutex_lock(&ctx->channels_lock);
    for(channel_info *ci = ctx->channels; ci != NULL; ci = ci->hh.next) {
        struct user_in_channel* cu = NULL;
        HASH_FIND_STR(ci->channel_users, nickname, cu);
        if (cu) {
            for(struct user_in_channel *channel_users = ci->channel_users;
                    channel_users != NULL; channel_users=channel_users->hh.next) {
                if (strcmp(channel_users->nickname, nickname) != 0) {
                    relay_QUIT(ctx, current_user, channel_users->client_socket, msg);
                }

            }
            HASH_DEL(ci->channel_users, cu);
        }
    }
    pthread_mutex_unlock(&ctx->channels_lock);
}
