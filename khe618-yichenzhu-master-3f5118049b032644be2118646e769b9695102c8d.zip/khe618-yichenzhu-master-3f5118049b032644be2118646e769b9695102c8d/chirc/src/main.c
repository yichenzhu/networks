#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <pthread.h>
#include <signal.h>
#include <errno.h>

#include "channel.h"
#include "log.h"
#include "server.h"
#include "message.h"
#include "user_connection.h"
#include "uthash.h"


/*
 * set_log_level - sets logging levels
 *
 * verbosity - compiler integer to set logging levels
 *
 * Returns - nothing.
 */
void set_log_level(int verbosity)
{
    switch(verbosity) {
    case -1:
        chirc_setloglevel(QUIET);
        break;
    case 0:
        chirc_setloglevel(INFO);
        break;
    case 1:
        chirc_setloglevel(DEBUG);
        break;
    case 2:
        chirc_setloglevel(TRACE);
        break;
    default:
        chirc_setloglevel(TRACE);
        break;
    }
}


/*
 * process_command_line_parameters - processes command line parameters with given input from console
 *
 * argc - argument count
 *
 * argv - argument vector
 *
 * server - server
 *
 * port - port
 *
 * passwd - password
 *
 * net_file - net file
 *
 * Returns: verbosity integer to check if the parameters are processed.
 */
int process_command_line_parameters(int argc, char*argv[], char** server, char** port, char** passwd, char** net_file)
{
    int opt;
    int verbosity = 0;
    while ((opt = getopt(argc, argv, "p:o:s:n:vqh")) != -1)
        switch (opt) {
        case 'p':
            *port = strdup(optarg);
            break;
        case 'o':
            *passwd = strdup(optarg);
            break;
        case 's':
            *server = strdup(optarg);
            break;
        case 'n':
            if (access(optarg, R_OK) == -1) {
                printf("ERROR: No such file: %s\n", optarg);
                exit(-1);
            }
            *net_file = strdup(optarg);
            break;
        case 'v':
            verbosity++;
            break;
        case 'q':
            verbosity = -1;
            break;
        case 'h':
            printf("Usage: chirc -o OPER_PASSWD [-p PORT] [-s SERVERNAME] [-n NETWORK_FILE] [(-q|-v|-vv)]\n");
            exit(0);
            break;
        default:
            fprintf(stderr, "ERROR: Unknown option -%c\n", opt);
            exit(-1);
        }

    if (!*passwd) {
        fprintf(stderr, "ERROR: You must specify an operator password\n");
        exit(-1);
    }

    if (*net_file && !*server) {
        fprintf(stderr, "ERROR: If specifying a network file, you must also specify a server name.\n");
        exit(-1);
    }

    return verbosity;
}

/*
 * start_irc_server - starts the irc server
 *
 * port - port ID
 *
 * Returns: server socket
 */
int start_irc_server(char* port)
{
    int server_socket;
    struct addrinfo hints, *res, *p;

    int yes = 1;
    //socklen_t sin_size = sizeof(struct sockaddr_in);

    memset(&hints, 0, sizeof hints);
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;
    hints.ai_flags = AI_PASSIVE; // Return my address, so I can bind() to it

    /* Note how we call getaddrinfo with the host parameter set to NULL */
    if (getaddrinfo(NULL, port, &hints, &res) != 0) {
        perror("getaddrinfo() failed");
        pthread_exit(NULL);
    }

    for(p = res; p != NULL; p = p->ai_next) {
        if ((server_socket = socket(p->ai_family, p->ai_socktype, p->ai_protocol)) == -1) {
            perror("Could not open socket");
            continue;
        }

        if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int)) == -1) {
            perror("Socket setsockopt() failed");
            close(server_socket);
            continue;
        }

        if (bind(server_socket, p->ai_addr, p->ai_addrlen) == -1) {
            perror("Socket bind() failed");
            close(server_socket);
            continue;
        }

        if (listen(server_socket, 5) == -1) {
            perror("Socket listen() failed");
            close(server_socket);
            continue;
        }
        break;
    }

    freeaddrinfo(res);

    return server_socket;
}



int main(int argc, char *argv[])
{
    /* If a client closes a connection, this will generally produce a SIGPIPE
       signal that will kill the process. We want to ignore this signal, so
       send() just returns -1 when this happens. */
    sigset_t new;
    sigemptyset (&new);
    sigaddset(&new, SIGPIPE);
    if (pthread_sigmask(SIG_BLOCK, &new, NULL) != 0) {
        perror("Unable to mask SIGPIPE");
        exit(-1);
    }

    struct server_ctx *ctx = calloc(1, sizeof(struct server_ctx));
    ctx->num_connections = 0;
    ctx->channels = NULL;
    ctx->users = NULL;
    ctx->other_servers = NULL;
    int num_users = 0;
    int num_clients = 0;
    int num_unknown = 0;
    int num_opers = 0;
    int num_servers = 1;
    ctx->num_users = &num_users;
    ctx->num_clients = &num_clients;
    ctx->num_unknown = &num_unknown;
    ctx->num_opers = &num_opers;
    ctx->num_servers = &num_servers;

    char server_hostname[MAX_MSG_LEN];
    gethostname(server_hostname, MAX_MSG_LEN);
    ctx->server_name = strdup(server_hostname);

    pthread_mutex_init(&ctx->users_lock, NULL);
    pthread_mutex_init(&ctx->channels_lock, NULL);
    pthread_mutex_init(&ctx->num_users_lock, NULL);
    pthread_mutex_init(&ctx->num_clients_lock, NULL);
    pthread_mutex_init(&ctx->num_unknown_lock, NULL);
    pthread_mutex_init(&ctx->num_opers_lock, NULL);
    pthread_mutex_init(&ctx->num_servers_lock, NULL);
    pthread_mutex_init(&ctx->servers_lock, NULL);
    pthread_mutex_init(&ctx->send_lock, NULL);


    //int opt;
    char* network_file = NULL;
    int verbosity = process_command_line_parameters(argc, argv,
                    &ctx->server_name,
                    &ctx->port,
                    &ctx->operpasswd,
                    &network_file);

    set_log_level(verbosity);

    if (network_file != NULL && ctx->server_name != NULL)
        read_server_configuration(ctx, network_file, ctx->server_name);

    int server_socket = start_irc_server(ctx->port);

    int result = process_user_connections(server_socket, ctx);

    free(network_file);
    free(ctx->port);
    free(ctx->sverpasswd);
    free(ctx->operpasswd);
    free(ctx->ip_address);
    free(ctx->server_name);

    close(server_socket);

    free(ctx->channels);
    free(ctx);

    return result;
}

