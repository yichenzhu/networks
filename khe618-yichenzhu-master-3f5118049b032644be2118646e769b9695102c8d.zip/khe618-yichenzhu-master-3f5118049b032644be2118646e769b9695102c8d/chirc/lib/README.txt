Add third-party libraries to this directory. 

Do *not* add them in the src/ directory! That directory
should only contain code written by you.